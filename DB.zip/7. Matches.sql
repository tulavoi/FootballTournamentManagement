﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY

--Chèn bảng Matches------------------------------------------------------------------------------------------------------------
----1. Matchweek 1
--GO
--INSERT INTO Matches(MatchID, RoundID, MatchName, MatchTime)
--VALUES('MW1_BUR-MCI', 'MW1', 'Burnley - Man City', '12/08/2023 2:00:00'),
--('MW1_ARS-NFO', 'MW1', 'Arsenal - Nottingham Forest', '12/08/2023 18:30:00'),
--('MW1_BOU-WHU', 'MW1', 'Bournemouth - West Ham', '12/08/2023 21:00:00'),
--('MW1_BHA-LUT', 'MW1', 'Brighton - Luton', '12/08/2023 21:00:00'),
--('MW1_EVE-FUL', 'MW1', 'Everton - Fulham', '12/08/2023 21:00:00'),
--('MW1_SHU-CRY', 'MW1', 'Sheffield United - Crystal Palace', '12/08/2023 21:00:00'),
--('MW1_NEW-AVL', 'MW1', 'Newcastle - Aston Villa', '12/08/2023 23:30:00'),
--('MW1_BRE-TOT', 'MW1', 'Brentford - Tottenham', '13/08/2023 20:00:00'),
--('MW1_CHE-LIV', 'MW1', 'Chelsea - Liverpool', '13/08/2023 22:30:00'),
--('MW1_MUN-WOL', 'MW1', 'Wolves - Man United', '15/08/2023 02:00:00')	

---- Lấy ID của vòng đấu
--DECLARE @RoundID CHAR(10)
--DECLARE @SeasonID INT

---- Cho người dùng nhập mùa giải
--SELECT @SeasonID = 1003

---- Lấy ID vòng đấu mới nhất của mùa giải đã chọn
--SELECT @RoundID = 'MW1_1001'
--FROM Rounds
--WHERE SeasonID = @SeasonID

---- Tạo 10 trận đấu mới
--DECLARE @MatchID CHAR(20)
--DECLARE @HomeID INT, @AwayID INT
--DECLARE @i INT = 1

--WHILE @i <= 10
--BEGIN
--	-- Lấy 2 câu lạc bộ tham gia trận đấu
--    SELECT @HomeID = ClubID 
--    FROM SeasonClubs
--    WHERE SeasonID = @SeasonID
--    ORDER BY NEWID()
--    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY

--	SELECT @AwayID = ClubID
--    FROM SeasonClubs 
--    WHERE SeasonID = @SeasonID AND ClubID <> @HomeID
--    ORDER BY NEWID()
--    OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY

-- --Tạo mã trận đấu mới
--    SET @MatchID = CONCAT(RTRIM(LTRIM(@RoundID)), '_', RIGHT('0' + CAST(@i AS VARCHAR(2)), 2))

--	-- Thêm trận đấu mới vào bảng Matches
--    INSERT INTO Matches (MatchID, SeasonID, RoundID, HomeID, AwayID, MatchName)
--    VALUES (@MatchID, @SeasonID, @RoundID, @HomeID, @AwayID, CONCAT('Match ', @i))
--	SET @i = @i + 1
--END

--DECLARE @RoundID CHAR(10)
--DECLARE @SeasonID INT

---- Cho người dùng nhập mùa giải
--SELECT @SeasonID = 1003

---- Lấy ID vòng đấu mới nhất của mùa giải đã chọn
--SELECT @RoundID = 'MW1_1001'
--FROM Rounds
--WHERE SeasonID = @SeasonID

---- Tạo 10 trận đấu mới
--DECLARE @MatchID CHAR(20)
--DECLARE @HomeID INT, @AwayID INT
--DECLARE @i INT = 1

---- Tạo bảng tạm để lưu trạng thái đã được chọn của mỗi đội
--DECLARE @SelectedClubs TABLE (
--    ClubID INT,
--    Selected BIT
--)

---- Đánh dấu tất cả các đội chưa được chọn trong bảng tạm
--INSERT INTO @SelectedClubs (ClubID, Selected)
--SELECT ClubID, 0
--FROM SeasonClubs
--WHERE SeasonID = @SeasonID

--WHILE @i <= 10
--BEGIN
--    -- Lấy 2 câu lạc bộ tham gia trận đấu
--    SELECT TOP 1 @HomeID = ClubID 
--    FROM @SelectedClubs
--    WHERE Selected = 0
--    ORDER BY NEWID()

--    -- Đánh dấu đội đã được chọn
--    UPDATE @SelectedClubs
--    SET Selected = 1
--    WHERE ClubID = @HomeID

--    SELECT TOP 1 @AwayID = ClubID
--    FROM @SelectedClubs 
--    WHERE Selected = 0
--    AND ClubID <> @HomeID
--    ORDER BY NEWID()

--    -- Đánh dấu đội đã được chọn
--    UPDATE @SelectedClubs
--    SET Selected = 1
--    WHERE ClubID = @AwayID

--    -- Tạo mã trận đấu mới
--    SET @MatchID = CONCAT(RTRIM(LTRIM(@RoundID)), '_', RIGHT('0' + CAST(@i AS VARCHAR(2)), 2))

--    -- Thêm trận đấu mới vào bảng Matches
--    INSERT INTO Matches (MatchID, SeasonID, RoundID, HomeID, AwayID, MatchName)
--    VALUES (@MatchID, @SeasonID, @RoundID, @HomeID, @AwayID, CONCAT('Match ', @i))
--    SET @i = @i + 1
--END 


--select * from Matches 
--select * from Matches where RoundID = 'MW1_1001'
--delete from Matches
-------------------------------------------------------------------------------------------------------------------------------