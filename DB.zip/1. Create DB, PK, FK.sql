GO
CREATE DATABASE [DBProject.Net]
GO
USE [DBProject.Net]
SET DATEFORMAT DMY

--DROP DATABASE [DBProject.Net]


--Seasons----------------------------------------------------------------
CREATE TABLE Seasons(
	SeasonID INT PRIMARY KEY IDENTITY(1001,1),
	SeasonName nvarchar(20) unique,
	StartDate date,
	EndDate date
)
--------------------------------------------------------------------------


--SeasonClubs----------------------------------------------------------------
CREATE TABLE SeasonClubs(
	SeasonID INT,
	ClubID INT,
	constraint PK_SeasonClubs primary key(SeasonID, ClubID)
)
--------------------------------------------------------------------------


--Clubs-------------------------------------------------------------------
CREATE TABLE Clubs(
	ClubID INT PRIMARY KEY IDENTITY(1001,1),
	ClubName NVARCHAR(30) NOT NULL UNIQUE,
	Logo NVARCHAR(50) UNIQUE
)
---------------------------------------------------------------------------


--Players----------------------------------------------------------------
CREATE TABLE Players(
	PlayerID INT PRIMARY KEY IDENTITY(1001,1),
	ClubID INT NOT NULL,
	Number INT,
	PlayerName NVARCHAR(30) NOT NULL UNIQUE,
	[Image] NVARCHAR(50),
	Country NVARCHAR(30) NOT NULL,
	Height FLOAT,
	[Weight] INT,
	DOB DATE,
	Salary INT,
	Position NVARCHAR(30),
	Foot NVARCHAR(20)
)
--------------------------------------------------------------------------



--Managers------------------------------------------------------------------
CREATE TABLE Managers(
	ManagerID INT PRIMARY KEY IDENTITY(1001,1),
	ClubID INT NOT NULL,
	ManagerName NVARCHAR(50) NOT NULL,
	[Image] NVARCHAR(50),
	Country NVARCHAR(30) NOT NULL,
	DOB DATE
)
----------------------------------------------------------------------------


--Stadiums------------------------------------------------------------------
CREATE TABLE Stadiums(
	StadiumID CHAR(20) NOT NULL UNIQUE,
	ClubID INT NOT NULL unique,
	StadiumName NVARCHAR(100) NOT NULL UNIQUE,
	[Image] NVARCHAR(50),
	Size VARCHAR(30),
	Capacity INT,
	[Location] NVARCHAR(100),
	BuiltTime DATE,
	constraint PK_StadiumID primary key (StadiumID)
)
----------------------------------------------------------------------------



--Rounds--------------------------------------------------------------------
CREATE TABLE Rounds(
	RoundID CHAR(10) NOT NULL,
	SeasonID INT,
	RoundName NVARCHAR(30) NOT NULL
	constraint PK_RoundID primary key (RoundID)
)
----------------------------------------------------------------------------


--Matches-------------------------------------------------------------------
CREATE TABLE Matches(
	MatchID CHAR(20) NOT NULL,
	SeasonID int,
	RoundID CHAR(10) NOT NULL,
	HomeID INT NOT NULL,
	AwayID INT NOT NULL,
	MatchName NVARCHAR(50),
	constraint PK_MatchID primary key (MatchID)
)
----------------------------------------------------------------------------


----DetailMatch-------------------------------------------------------------
CREATE TABLE MatchDetail(
	MatchID CHAR(20) NOT NULL,
	MotmID INT NOT NULL,
	HomeGoals INT,
	AwayGoals INT,
	HomeCapID INT NOT NULL,
	AwayCapID INT NOT NULL,
	HomeTactical NVARCHAR(50) NOT NULL,
	AwayTactical NVARCHAR(50) NOT NULL,
	RefereeID INT,
	MatchTime DateTime,
	constraint PK_DetailMatch primary key (MatchID, MotmID, HomeCapID, AwayCapID, RefereeID)
)
----------------------------------------------------------------------------


--Referees------------------------------------------------------------------
CREATE TABLE Referees(
	RefereeID INT PRIMARY KEY IDENTITY(1001,1),
	RefereeName NVARCHAR(50) NOT NULL,
	[Image] NVARCHAR(50),
	Country NVARCHAR(30) NOT NULL,
	DOB DATE
)
----------------------------------------------------------------------------


--PlayersInMatch------------------------------------------------------------
CREATE TABLE PlayersInMatch(
	MatchID CHAR(20) NOT NULL,
	PlayerID INT NOT NULL,
	IsHomeTeam INT NOT NULL,
	Position NVARCHAR(20),
	Goal INT,
	YellowCard INT,
	RedCard INT,
	OwnGoal INT,
	constraint PK_PlayersInMatch primary key (MatchID, PlayerID)
)
----------------------------------------------------------------------------



--Standings-----------------------------------------------------------------
CREATE TABLE Standings(
	StandingID INT PRIMARY KEY IDENTITY (1,1),
	ClubID INT NOT NULL,
	Played INT,
	Won INT,
	Drawn INT,
	Lost INT, 
	GoalsFor INT,
	GoalsAgainst INT,
	GoalDifference INT,
	Points INT
)
-----------------------------------------------------------------------------


--Accounts-----------------------------------------------------------------
CREATE TABLE Accounts(
	AccountID INT PRIMARY KEY IDENTITY (1,1),
	Email nvarchar(50),
	[Password] nvarchar(50),
	Permission bit
)
-----------------------------------------------------------------------------


--Add foreign key-----------------------------------------------------
alter table SeasonClubs
add constraint FK_SeasonClub_SeasonID foreign key(SeasonID) references Seasons(SeasonID)
alter table SeasonClubs
add constraint FK_SeasonClub_ClubID foreign key(ClubID) references Clubs(ClubID)

alter table Players
add constraint FK_Player_ClubID foreign key(ClubID) references Clubs(ClubID)

alter table Stadiums
add constraint FK_Stadium_ClubID foreign key(ClubID) references Clubs(ClubID)

alter table Managers
add constraint FK_Manager_ClubID foreign key(ClubID) references Clubs(ClubID)

alter table Matches
add constraint FK_Match_SeasonID foreign key(SeasonID) references Seasons(SeasonID)
alter table Matches
add constraint FK_Match_RoundID foreign key(RoundID) references Rounds(RoundID)
alter table Matches
add constraint FK_Match_HomeID foreign key(HomeID) references Clubs(ClubID)
alter table Matches
add constraint FK_Match_AwayID foreign key(AwayID) references Clubs(ClubID)

alter table Rounds
add constraint FK_Round_SeasonID foreign key(SeasonID) references Seasons(SeasonID)

alter table MatchDetail
add constraint FK_MatchDetail_MatchID foreign key(MatchID) references Matches(MatchID)
alter table MatchDetail
add constraint FK_MatchDetail_MotmID foreign key(MotmID) references Players(PlayerID)
alter table MatchDetail
add constraint FK_MatchDetail_HomeCaptainID foreign key(HomeCapID) references Players(PlayerID)
alter table MatchDetail
add constraint FK_MatchDetail_AwayCapID foreign key(AwayCapID) references Players(PlayerID)
alter table MatchDetail
add constraint FK_MatchDetail_RefereeID foreign key(RefereeID) references Referees(RefereeID)

ALTER TABLE PlayersInMatch
ADD CONSTRAINT FK_PlayersInMatch_PlayerID FOREIGN KEY(PlayerID) REFERENCES Players(PlayerID)
ALTER TABLE PlayersInMatch
ADD CONSTRAINT FK_PlayersInMatch_MatchID FOREIGN KEY(MatchID) REFERENCES Matches(MatchID)

ALTER TABLE Standings
ADD CONSTRAINT FK_Standings_ClubID FOREIGN KEY(ClubID) REFERENCES Clubs(ClubID)