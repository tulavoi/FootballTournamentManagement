﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY


GO
INSERT INTO Accounts(Email, [Password], Permission)
VALUES('toilavu@gmail.com', '1', 1),
('cong@gmail.com', '1', 1),
('user@gmail.com', '1', 0)


--SELECT * FROM Seasons

--DELETE FROM Seasons
-------------------------------------------------------------------------------------------------------------------------------