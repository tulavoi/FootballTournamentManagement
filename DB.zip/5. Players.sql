﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY
--SELECT * FROM players

--Chèn bảng CauThu
--1. ARSENAL--------------------------------------------------------------------------
-------------------GOALKEEPERS-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1001, 1, 'Aaron Ramsdale', 'aaronramsdale.png', 'England', 1.88, 77, '14/05/1998', 6240000, N'Goalkeeper', 'Right'),
(1026, 13, 'Runar Alex Runarsson', null, N'Iceland', 1.86, null, '18/02/1995', 780000, N'Goalkeeper', 'Right'),
(1001, 22, 'David Raya', null, N'Spain', 1.83, 80, '15/09/1995', 1300000, N'Goalkeeper', 'Right'),
(1001, 31, 'Karl Hein', null, N'Estonia', 1.93, 86, '13/04/2002', 156000, N'Goalkeeper', 'Right'),
(1026, 33, 'Arthur Okonkwo', null, N'England', 1.98, 86, '09/09/2001', 130000, N'Goalkeeper', 'Right'),

-------------------DEFENDERS-------------------
(1001, 2, N'William Saliba', 'williamsaliba.png', N'France', 1.92, 92, '24/03/2001', 9880000, N'Defender', 'Right'),
(1026, 3, N'Kieran Tierney', null, N'Scotland', 1.78, 70, '15/12/1997', 5720000, N'Defender', 'Left'),	
(1001, 4, N'Ben White', 'benwhite.png', N'England', 1.82, 77, '08/10/1997', 6240000, N'Defender', 'Right'),
(1001, 6, N'Gabriel Magalhães', null, N'Brazil', 1.89, 78, '19/12/1997', 5200000, N'Defender', 'Left'),
(1001, 12, N'Jurriën Timber', null, N'Netherlands', 1.79, 79, '17/06/2001', 4680000, N'Defender', 'Right'),
(1001, 15, 'Jakub Kiwior', 'jakubkiwior.png', N'Poland', 1.89, 75, '15/02/2000', 3016000, N'Defender', 'Right'),
(1001, 17, N'Cédric Soares', null, N'Portugal', 1.72, 67, '31/08/1991', 1300000, N'Defender', 'Right'),
(1001, 18, N'Tomiyasu Takehiro', null, N'Brazil', 1.88, 78, '05/11/1998', 2860000, N'Defender', 'Both'),
(1001, 35, N'Oleksandr Zinchenko', null, N'Brazil', 1.75, 64, '15/12/1996', 7800000, N'Defender', 'Left'),

-------------------MIDFIELDERS-------------------
(1001, 5, N'Thomas Partey', 'thomaspartey.png', N'Ghana', 1.85, 75, '13/06/1993', 10400000, N'Midfielder', 'Right'),
(1001, 8, N'Martin Ødegaard', null, N'Norway', 1.78, 69, '17/12/1998', 5980000, N'Midfielder', 'Left'),
(1001, 10, N'Emile Smith Rowe', null, N'England', 1.82, 77, '28/07/2000', 2080000, N'Midfielder', 'Right'),
(1001, 20, N'Jorginho', 'jorginho.png',N'Italy', 1.80, 65, '20/12/1991', 5720000, N'Midfielder', 'Both'),
(1001, 21, N'Fábio Vieira', null, N'Portugal', 1.70, 65, '30/05/2000', 2340000, N'Midfielder', 'Left'),
(1001, 25, N'Mohamed Elneny', 'mohamedelneny.png', N'Egypt', 1.81, 74, '11/07/1992', 2860000, N'Midfielder', 'Right'),
(1001, 29, N'Kai Havertz', null, N'Germany', 1.93, 83, '11/06/1999', 14560000, N'Midfielder', 'Both'),
(1001, 41, N'Declan Rice', null, N'England', 1.85, 84, '14/01/1999', 12480000, N'Midfielder', 'Right'),

-------------------FORWARDS-------------------
(1001, 7, N'Bukayo Saka', 'bukayosaka.png', N'England', 1.78, 73, '05/09/2001', 10140000, N'Forward', 'Left'),
(1001, 9, N'Gabriel Jesus', 'gabrieljesus.png', N'Brazil', 1.75, 73, '03/04/1997', 13780000, N'Forward', 'Right'),
(1001, 11, N'Gabriel Martinelli', null, N'Brazil', 1.80, 75, '18/06/2001', 9360000, N'Forward', 'Right'),
(1001, 14, N'Eddie Nketiah', 'eddienketiah.png', N'England', 1.80, 70, '30/05/1999', 5200000, N'Forward', 'Right'),
(1001, 19, N'Leandro Trossard', null, N'Belgium', 1.72, 61, '04/12/1994', 4680000, N'Forward', 'Right'),
(1026, 19, N'Nicolas Pépé', null, N'Belgium', 1.83, 73, '29/05/1995', 7280000, N'Forward', 'Left'),
(1001, 24, N'Reiss Nelson', null, N'England', 1.76, 66, '10/12/1999', 5200000, N'Forward', 'Right'),
(1026, 27, N'Marquinhos', null, N'Brazil', 1.75, 85, '07/04/2003', 1560000, N'Forward', 'Left')


--2. ASTON VILLA----------------------------------------------------------------------
-------------------GOALKEEPERS-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1002, 1, N'Emiliano Martínez', 'emilianomartinez.png','Argentina', 1.92, 89, '02/09/1992', 6240000, N'Goalkeeper', 'Right'),
(1002, 25, N'Robin Olsen', null,N'Sweden', 1.98, 89, '08/01/1990', 2600000, N'Goalkeeper', 'Right'),
(1026, 38, N'Viljami Sinisalo', null,N'Finland', 1.90, null, '11/10/2001', 0, N'Goalkeeper', null),
(1026, 42, N'Filip Marschall', null,N'England', 1.95, null, '24/04/2003', 0, N'Goalkeeper', null),
(1026, null, N'Oliwier Zych', null,N'Poland', 1.93, NULL, '28/06/2004', 0, N'Goalkeeper', null),

-------------------DEFENDERS-------------------
(1002, 2, N'Matty Cash', 'mattycash.png','Poland', 1.85, 64, '07/08/1997', 4160000, N'Defender', 'Right'),
(1002, 3, N'Diego Carlos', null,'Brazil', 1.85, 79, '15/03/1993', 5200000, N'Defender', 'Right'),
(1002, 4, N'Ezri Konsa', 'ezrikonsa.png','England', 1.83, 77, '23/10/1997', 1560000, N'Defender', 'Right'),
(1002, 5, N'Tyrone Mings', null,'England', 1.96, 77, '13/03/1993', 5200000, N'Defender', 'Left'),
(1002, 12, N'Lucas Digne', 'lucasdigne.png',N'France', 1.78, 74, '20/07/1993', 6240000, N'Defender', 'Left'),
(1002, 14, N'Pau Torres', null,N'Spain', 1.91, 80, '16/01/1997', 0, N'Defender', 'Left'),
(1002, 15, N'Álex Moreno', null,N'Spain', 1.79, 68, '08/06/1993', 1820000, N'Defender', 'Left'),
(1002, 16, N'Calum Chambers', null,N'England', 1.82, 66, '20/01/1995',2600000, N'Defender', 'Right'),
(1002, 17, N'Clément Lenglet', null,N'France', 1.86, 81, '17/06/1995', 7800000, N'Defender', 'Left'),
(1002, 30, N'Kortney Hause', null,N'England', 1.91, 77, '16/07/1995', 420000, N'Defender', 'Left'),

-------------------MIDFIELDERS-------------------
(1002, 6, N'Douglas Luiz', 'douglasluiz.png',N'Brazil', 1.75, 65, '09/05/1998', 3900000, N'Midfielder', 'Right'),
(1002, 7, N'John McGin', 'johnmacginn.png',N'Scotland', 1.78, 68, '18/10/1994', 6240000, N'Midfielder', 'Left'),
(1002, 8, N'Youri Tielemans', null,N'Belgium', 1.76, 72, '07/05/1997', 6240000, N'Midfielder', 'Both'),
(1002, 9, N'Bertrand Traoré', null,N'Burkinabe', 1.81, 73, '06/09/1995', 4050000, N'Midfielder', 'Left'),
(1002, 10, N'Emiliano Buendía', null,N'Brazil', 1.72, 65, '25/12/1996', 3900000, N'Midfielder', 'Right'),
(1002, 19, N'Moussa Diaby', 'moussadiaby.png',N'France', 1.70, 68, '07/07/1999', 0, N'Midfielder', 'Left'),
(1002, 22, N'Nicolò Zaniolo', null,N'Italy', 1.90, 79, '02/07/1999', 3120000, N'Midfielder', 'Left'),
(1026, 23, N'Philippe Coutinho', null,N'Brazil', 1.72, 71, '12/06/1992', 6500000, N'Midfielder', 'Right'),
(1002, 31, N'Leon Bailey', 'leonbailey.png',N'Jamaica', 1.81, 75, '09/08/1997', 5200000, N'Midfielder', 'Left'),
(1002, 32, N'Leander Dendoncker', null,N'Belgium', 1.88, 83, '15/04/1995', 4680000, N'Midfielder', 'Right'),
(1026, 33, N'Jaden Philogene', null,N'England', 1.81, null, '08/02/2002', 0, N'Midfielder', 'Right'),
(1002, 41, N'Jacob Ramsey', null,N'England', 1.80, 75, '28/05/2001', 3640000, N'Midfielder', 'Right'),
(1002, 44, N'Boubacar Kamara', null,N'France', 1.84, 68, '23/11/1999', 7800000, N'Midfielder', 'Right'),
(1002, 47, N'Tim Iroegbunam', null,N'England', null, null, '30/06/2003', 210000, N'Midfielder', null),
(1002, 71, N'Omari Kellyman', null,N'Northern Ireland', null, null, '25/09/2005', 0, N'Midfielder', null),

-------------------FORWARDS-------------------
(1002, 11, N'Ollie Watkins', 'olliewatkins.png',N'Burkinabe', 1.80, 70, '30/12/1995', 3900000, N'Forward', 'Right'),
(1002, 24, N'Jhon Durán', 'jhondurán.png',N'Colombia', 1.85, 73, '13/12/2003', 1560000, N'Forward', 'Right')


--3. BOURNEMOUTH----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1003, 1, N'Neto',  'neto.png', N'Brazil', 1.90, 84, '19/07/1989', 2600000, N'Goalkeeper', 'Right'),
(1003, 12, N'Darren Randolph', null, N'Republic of Ireland', 1.88, 98, '12/05/1987', 1300000, N'Goalkeeper', 'Right'),
(1003, 20, N'Andrei Radu', null, N'Romania', 1.88, 70, '28/05/1997', 0, N'Goalkeeper','Right'),

-------------------Defenders-------------------
(1003, 2, N'Ryan Fredericks', 'ryanfredericks.png', N'England', 1.81, 74, '10/10/1992', 1820000, N'Defender', 'Right'),
(1003, 3, N'Milos Kerkez', 'miloskerkez.png', N'Hungary', 1.80, 71, '07/11/2003', 1300000, N'Defender', 'Left'),
(1003, 5, N'Lloyd Kelly', 'lloydkelly.png', N'England', 1.78, 70, '06/10/1998', 1560000, N'Defender', 'Left'),
(1003, 6, N'Chris Mepham', null, N'Wales', 1.93, 88, '05/11/1997', 1820000, N'Defender', 'Right'),
(1003, 15, N'Adam Smith', null, N'Uruguay', 1.80, 78, '29/04/1997', 1820000, N'Defender', 'Right'),
(1026, 23, N'James Hill', null, N'England', 1.84, 73, '10/01/2002', 156000, N'Defender', 'Right'),
(1003, 25, N'Marcos Senesi', null, N'Argentina', 1.85, 80, '10/05/1997', 2600000, N'Defender', 'Left'),
(1003, 27, N'Illia Zabarnyi', null, N'Ukraine', 1.78, 70, '01/09/2002', 1300000, N'Defender', 'Right'),
(1003, 37, N'Max Aarons', null, N'England', 1.78, 69, '04/01/2000', 0, N'Defender', 'Right'),
(1003, 43, N'Ben Greenwood', null, N'Republic of Ireland', 1.70, 70, '20/02/2003', 0, N'Defender', null),

-------------------Midfielders--------------------
(1003, 4, N'Lewis Cook', 'lewiscook.png', N'England', 1.75, 71, '03/02/1997', 2080000, N'Midfielder', 'Right'),
(1003, 7, N'David Brooks', null, N'Wales', 1.73, 62, '08/07/1997', 2600000, N'Midfielder', 'Left'),
(1003, 8, N'Joe Rothwell', null, N'England', 1.85, 77, '11/01/1995' , 416000, N'Midfielder', 'Right'),
(1003, 10, N'Ryan Christie', null, N'Scotland', 1.78, 79, '22/02/1995', 1560000, N'Midfielder', 'Left'),
(1003, 13, N'Emiliano Marcondes', null, N'Denmark', 1.82, 75, '09/03/1995', 780000, N'Midfielder', 'Right'),
(1003, 14, N'Alex Scott', 'alexscott.png', N'England', null, null, '21/08/2003' , 0, N'Midfielder', null),
(1003, 16, N'Marcus Tavernier', null, N'England', 1.78, 80, '22/03/1999', 1820000, N'Midfielder', null),
(1003, 18, N'Tyler Adams', 'tyleradams.png', N'USA', 1.73, 72, '14/02/1999', 3120000, N'Midfielder', 'Right'),
(1003, 22, N'Hamed Junior Traorè', null, N'Côte dIvoire', 1.84, 77, '16/02/2000', 2340000, N'Midfielder', 'Right'),
(1003, 26, N'Gavin Kilkenny', null, N'Republic of Ireland', 1.70, null, '01/02/2000', 78000, N'Midfielder', 'Right'),
(1003, 29, N'Philip Billing', null, N'Denmark', 1.93, 83, '11/06/1996', 2080000, N'Midfielder', 'Left'),

-------------------Forwards-------------------
(1003, 9, N'Dominic Solanke', 'dominicsolanke.png', N'England', 1.87, 80, '14/09/1997', 2600000, N'Forward', 'Right'),
(1003, 11, N'Dango Ouattara', 'dangoouattara.png', N'Burkina Faso', 1.77, 71, '11/02/2002', 1820000, N'Forward', null),
(1003, 17, N'Luis Sinisterra', null, N'Colombia', 1.72, 60, '17/06/1999', 3380000, N'Forward', 'Right'),
(1003, 19, N'Justin Kluivert', null, N'Netherlands', 1.71, 67, '06/06/1999', 4160000, N'Forward', 'Right'),
(1003, 21, N'Kieffer Moore', null, N'England', 1.96, 89, '08/08/1992', 780000, N'Forward', 'Right'),
(1003, 24, N'Antoine Semenyo', 'antoinesemenyo.png', N'England', 1.85, 79, '07/01/2000', 1040000, N'Forward', null),
(1026, 32, N'Jaidon Anthony', null, N'England', 1.83, null, '01/12/1999', 1300000, N'Forward', null)


--4. BRENTFORD------------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1004, 1, 'Mark Flekken', 'markflekken.png', N'Netherlands', 1.95, 87, '13/06/1993', 0, N'Goalkeeper', 'Both'),
(1004, 21, 'Thomas Strakosha', null, N'Albania', 1.86, 78, '19/03/1995', 1300000, N'Goalkeeper', 'Right'),
(1004, 34, 'Matthew Cox', null, N'England', 1.82, 64, '02/05/2003', null, N'Goalkeeper', null),
(1004, 40, 'Ellery Balcombe', null, N'England', 1.90, 92, '15/10/1999', null, N'Goalkeeper','Right'),

-------------------Defenders-------------------
(1004, 2, 'Aaron Hickey', 'aaronhickey.png', N'Scotland', 1.78, 72, '10/06/2002', 1560000, N'Defender', 'Left'),
(1004, 3, 'Rico Henry', 'ricohenry.png', N'England', 1.70, 66, '08/07/1997', 1820000, N'Defender', 'Left'),
(1004, 4, 'Charlie Goode', null, N'England', 1.96, 84, '03/08/1995', 416000, N'Defender', 'Right'),
(1004, 5, 'Ethan Pinnock', null, N'England', 1.87, 82, '29/05/1993', 1560000, N'Defender', 'Left'),
(1004, 13, N'Mathias Jørgensen', null, N'Denmark', 1.91, 79, '23/04/1990', 2600000, N'Defender', 'Right'),
(1004, 16, 'Ben Mee', 'benmee.png', N'England', 1.80, 74, '21/09/1989', 2860000, N'Defender', 'Left'),
(1004, 20, 'Kristoffer Ajer', null, N'Norway', 1.96, 84, '17/04/1998', 1820000, N'Defender', 'Right'),
(1004, 22, 'Nathan Collins', null, N'Republic of Ireland', 1.93, null, '30/04/2001', 0, N'Defender', 'Right'),
(1004, 30, 'Mads Roerslev Rasmussen', null, N'Denmark', 1.77, 72, '24/06/1999', 1040000, N'Defender', 'Right'),
(1004, 33, 'Fin Stevens', null, N'Wales', null, null, '10/04/2003', 0, N'Defender', 'Right'),

-------------------Midfielders-------------------
(1004, 6, N'Christian Nørgaard', null, N'Denmark', 1.85, 76, '10/03/1994', 1820000, N'Midfielder', 'Right'),
(1004, 8, 'Mathias Jensen', 'mathiasjensen.png', N'Denmark', 1.80, 68, '01/01/1996', 2600000, N'Midfielder', 'Both'),
(1004, 10, 'Joshua Da Silva', 'joshdasilva.png', N'England', 1.84, 70, '23/10/1998', 1040000, N'Midfielder', 'Left'),
(1004, 11, 'Yoane Wissa', null, N'DR Congo', 1.80, 75, '03/09/1996', 1300000, N'Midfielder', 'Right'),
(1004, 15, 'Frank Onyeka', null, N'Nigeria', 1.83, 78, '01/01/1998', 1300000, N'Midfielder', 'Right'),
(1004, 24, 'Mikkel Damsgaard', null, N'Denmark', 1.80, 66, '03/07/2000', 1560000, N'Midfielder', 'Right'),
(1004, 25, 'Myles Peart-Harris', null, N'England', 1.80, 66, '18/09/2002', 0, N'Midfielder', null),
(1004, 26, 'Shandon Baptiste', null, N'Grenada', 1.80, 67, '08/04/1998', 780000, N'Midfielder', 'Right'),
(1004, 27, 'Vitaly Janelt', null, N'Germany', 1.84, 79, '10/05/1998', 1560000, N'Midfielder', 'Right'),
(1004, 33, 'Yehor Yarmoliuk', null, N'Ukraine', 1.80, 72, '01/03/2004', 0, N'Midfielder', 'Both'),
(1004, 37, 'Michael Olakigbe', null, N'England', null, null, '25/04/2004', 0, N'Midfielder', null),
(1004, 38, 'Ethan Brierley', 'ethabbrierley.png', N'England', 1.68, null, '23/11/2003', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1004, 7, N'Neal Maupay', null, 'France', 1.73, 69, '14/08/1996', 2600000, N'Forward', 'Right'),
(1004, 9, 'Kevin Schade', 'kevinschade.png', N'Germany', 1.83, 74, '27/11/2001', 520000, N'Forward', 'Right'),
(1004, 14, 'Saman Ghoddos', 'samanghoddos.png', N'Sweden', 1.76, 79, '06/09/1993', 1040000, N'Forward', 'Right'),
(1004, 17, 'Ivan Toney', 'ivantoney.png', N'England', 1.79, 70, '16/03/1996', 1040000, N'Forward', 'Right'),
(1004, 19, 'Bryan Mbeumo', null, N'Cameroon', 1.73, 64, '07/08/1999', 2340000, N'Forward', 'Left'),
(1004, 23, 'Keane Lewis-Potter', null, N'England', 1.70, 67, '22/02/2001', 1820000, N'Forward', 'Right')


--5.BRIGHTON & HOVE ALBION-----------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1005, 1, N'Robert Sánchez', null, N'Spain', 1.97, 94, '18/11/1997', 1300000, N'Goalkeeper', 'Right'),
(1005, 23, 'Jason Steele', null, N'England', 1.88, 79, '18/08/1990', 1040000, N'Goalkeeper', 'Right'),
(1005, 38, 'Tom McGill', 'tommcgill.png', N'Canada', 1.85, 80, '25/03/2000', 520000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1005, 2, 'Tariq Lamptey', null, N'Ghana', 1.65, 60, '30/09/2000', 1820000, N'Defender', 'Right'),
(1005, 3, 'Igor Julio', 'igorjulio.png', N'Ghana', 1.85, 85, '07/02/1998', 520000, N'Defender', 'Left'),
(1005, 4, 'Adam Webster', 'adamwebster.png', N'England', 1.90, 75, '04/01/1995', 2860000, N'Defender', 'Right'),
(1005, 5, 'Lewis Dunk', 'lewisdunk.png', N'England', 1.90, 77, '21/11/1991', 4160000, N'Defender', 'Right'),
(1005, 29, 'Jan Paul van Hecke', null, N'Netherlands', 1.89, 84, '08/06/2000', 260000, N'Defender', 'Right'),
(1005, 30, N'Pervis Estupiñán', null, N'Ecuador', 1.75, 73, '21/1/1998', 2600000, N'Defender', 'Left'),
(1005, 34, N'Joël Veltman', null, N'Netherlands', 1.82, 73, '15/1/1992', 2600000, N'Defender', 'Right'),

-------------------Midfielders-------------------
(1005, 6, 'James Milner', 'jamesmilner.png', 'England', 1.75, 70, '04/01/1986', 0, N'Midfielder', 'Right'),
(1005, 7, 'Solly March', 'sollymarch.png', N'England', 1.85, 77, '26/12/1994', 2600000, N'Midfielder', 'Left'),
(1005, 8, 'Mahmoud Dahoud', null, N'Germany', 1.78, 68, '01/01/1996', 0, N'Midfielder', 'Right'),
(1005, 11, 'Billy Gilmour', null, N'Scotland', 1.66, 60, '11/06/2001', 1040000, N'Midfielder', 'Right'),
(1005, 13, N'Pascal Groß', null, N'Germany', 1.81, 78, '15/06/1991', 3380000, N'Midfielder', 'Right'),
(1005, 14, N'Adam Lallana', null, N'England', 1.72, 73, '10/05/1998', 4680000, N'Midfielder', 'Both'),
(1005, 15, 'Jakub Moder', 'jakubmoder.png', N'Poland', 1.88, 83, '07/04/1999', 520000, N'Midfielder', 'Right'),
(1026, 17, N'Steven Alzate', null, N'Colombia', 1.80, 75, '08/09/1998', 780000, N'Midfielder', 'Right'),
(1005, 20, 'Carlos Baleba', null, N'Cameroon', null, null, '03/01/2004', 650000, N'Midfielder', null),
(1005, 22, N'Mitoma Kaoru', null, N'Japan', 1.78, 75, '20/05/1997', 520000, N'Midfielder', 'Right'),
(1005, 40, 'Facundo Buonanotte', null, N'Argentina', 1.74, 66, '23/12/2004', 780000, N'Midfielder', 'Left'),

-------------------Forwards-------------------
(1005, 9, N'João Pedro', null, N'Brazil', 1.82, 70, '26/09/2001', 0, N'Forward', 'Right'),
(1005, 10, N'Julio Enciso', 'julioenciso.png', N'Paraguay', 1.68, 64, '23/01/2004', 520000, N'Forward', 'Right'),
(1005, 18, N'Danny Welbeck', null, N'England', 1.85, 73, '26/11/1990', 4680000, N'Forward', 'Right'),
(1026, 19, N'Andi Zeqiri', null, N'Switzerland', 1.85, 81, '22/06/1999', 1378000, N'Forward', 'Left'),
(1005, 24, N'Simon Adingra', null, N'Côte dIvoire', 1.75, 68, '01/01/2002', 0, N'Forward', 'Left'),
(1005, 28, N'Evan Ferguson', 'evanferguson.png', N'Republic of Ireland', 1.83, 78, '19/10/2004', 1040000, N'Forward', null),
(1005, 31, N'Ansu Fati', 'ansufati.png', N'Spain', 1.78, 66, '31/10/2002', 8320000, N'Forward', 'Right')

--6. BURLEY FC--------------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1006, 1, N'James Trafford', 'jamestrafford.png', N'England', 1.92, null, '10/10/2002', 0, N'Goalkeeper', 'Right'),
(1006, 20, N'Denis Franchi', null, N'Italy', null, null, '22/10/2002', 30000, N'Goalkeeper', null),
(1006, 29, N'Lawrence Vigouroux', null, N'Chile', 1.94, 77, '19/11/1993', 0, N'Goalkeeper', 'Right'),
(1006, 49, N'Arijanet Muric', null, N'Kosovo', 1.98, 81, '07/11/1998', 1040000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1006, 2, N'Dara OShea', null, N'Republic of Ireland', null, null, '04/03/1999', 0, N'Defender', null),
(1006, 3, N'Charlie Taylor', 'charlietaylor.png', N'England', 1.76, 70, '18/09/1993', 1300000, N'Defender', 'Left'),
(1006, 5, N'Jordan Beyer', 'jordanbeyer.png', N'Germany', 1.87, 80, '19/05/2000', 160000, N'Defender', 'Right'),
(1006, 6, N'CJ Egan-Riley', null, N'England', null, null, '02/01/2003', 280000, N'Defender', null),
(1006, 14, N'Connor Roberts', null, N'Wales', 1.75, 72, '23/09/1995', 1360000, N'Defender', 'Right'),
(1006, 18, N'Hjalmar Ekdal', null, N'Swenden', 1.88, 77, '21/10/1998', 936600, N'Defender', 'Right'),
(1006, 21, N'Luke McNally', null, N'Republic of Ireland', 1.84, null, '20/09/1999', 890000, N'Defender', 'Right'),
(1006, 22, N'Vitinho', 'vitinho.png', N'Brazil', 1.75, 72, '23/07/1999', 600000, N'Defender', 'Right'),
(1006, 28, N'Ameen Al-Dakhil', null, N'Belgium', 1.87, 70, '06/03/2002', 572000, N'Defender', 'Right'),
(1006, 39, N'Owen Dodgson', null, N'England', null, null, '19/03/2003', null, N'Defender', null),
(1006, 44, N'Hannes Delcroix', null, N'Belgium', 1.85, 78, '28/02/1999', null, N'Defender','Left'),

-------------------Midfielders-------------------
(1006, 4, N'Jack Cork', 'jackcork.png', N'Germany', 1.83, 70, '25/06/1989', 1980000, N'Midfielder', 'Right'),
(1006, 7, N'Jóhann Gudmundsson', null, N'Iceland', 1.86, 78, '27/10/1990', 1560000, N'Midfielder', 'Left'),
(1006, 8, N'Josh Brownhill', null, N'England', 1.78, 69, '19/12/1995', 2080000, N'Midfielder', 'Right'),
(1026, 11, N'Scott Twine', null, N'England', 1.74, 69, '14/07/1999', 180000, N'Midfielder', 'Right'),
(1006, 16, 'Sander Berge', 'sanderberge.png', N'Norway', 1.95, 96, '14/02/1998', 1700000, N'Midfielder', 'Right'),
(1006, 24, N'Josh Cullen', 'joshcullen.png', N'Republic of Ireland', 1.75, 70, '07/04/1996', 910000, N'Midfielder', 'Right'),
(1026, 26, N'Samuel Bastien', null, N'Congo DR', 1.75, 75, '26/09/1996', 780000, N'Midfielder', 'Right'),
(1006, 31, N'Mike Trésor', null, N'Belgium', 1.72, 64, '28/05/1999', 520000, N'Midfielder', 'Right'),
(1006, 42, N'Han-Noah Massengo', null, N'France', 1.78, null, '07/07/2001', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1006, 9, N'Jay Rodríguez', null, N'England', 1.85, 80, '29/07/1989', 1820000, N'Forward', 'Right'),
(1006, 10, N'Benson Manuel', 'bensonmanuel.png', N'Belgium', 1.78, 68, '28/03/1997', 860000, N'Forward', 'Left'),
(1026, 13, N'Wout Weghorst', null, N'Netherlands', 1.97, 84, '07/08/1992', 1820000, N'Forward', 'Right'),
(1006, 15, N'Nathan Redmond', null, N'Netherlands', 1.73, 69, '06/03/1994', 0, N'Forward', 'Right'),
(1006, 17, N'Lyle Foster', 'lylefoster.png', N'South Africa', 1.85, 70, '03/09/2000', 1040000, N'Forward', 'Right'),
(1006, 19, N'Anass Zaroury', null, N'Morocco', 1.76, 70, '28/03/1997', 480000, N'Forward', 'Right'),
(1006, 25, N'Zeki Amdouni', 'zekiamdouni.png', N'Switzerland', 1.85, 79, '04/12/2000', 0, N'Forward', 'Both'),
(1006, 27, N'Darko Churlinov', null, N'North Macedonia', 1.71, 73, '11/07/2000', 440000, N'Forward', 'Right'),
(1006, 30, N'Luca Koleosho', null, N'Italy', 1.75, 68, '15/09/2004', 0, N'Forward', 'Right'),
(1006, 34, N'Jacob Bruun Larsen', null, N'Denmark', 1.87, 77, '19/09/1998', 0, N'Forward', 'Left'),
(1006, 45, N'Michael Obafemi', null, N'Ireland', 1.69, 71, '06/07/2000', 670000, N'Forward', 'Right'),
(1006, 47, N'Wilson Odobert', null, N'France', null, null, '28/11/2004', 0, N'Forward', null),
(1006, 48, N'Enock Agyei', null, N'Belgium', 1.72, null, '13/02/2005', 0, N'Forward', 'Left')


--7. CHELSEA--------------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1007, 13, N'Marcus Bettinelli', null,N'England', 1.94, 82, '24/05/1992', 1820000, N'Goalkeeper', 'Right'),
(1007, 1, N'Robert Sanchez', null,N'Spain', 1.97, 90, '18/11/1997', 0, N'Goalkeeper', 'Left'),
(1007, 28, N'Djordje Petrovic', 'djordjepetrovic.png',N'Serbia', 1.94, null, '08/10/1999', 0, N'Goalkeeper', null),
(1007, 47, N'Lucas Bergström', null,'Finland', 1.99, 82, '05/09/2002', 0, N'Goalkeeper', null),
(1007, 50, N'Eddie Beach', null,'Wales', 1.96, null, '14/11/2003', 0, N'Goalkeeper', null),

-------------------Defenders-------------------
(1007, 2, N'Axel Disasi', 'axeldisasi.png',N'France', 1.90, 83, '11/03/1998', 0, N'Defender', 'Right'),
(1007, 3, N'Marc Cucurella', null,N'Spain', 1.72, 66, '22/07/1998', 9100000, N'Defender', 'Left'),
(1007, 5, N'Benoît Badiashile', null,N'France', 1.94, 75, '26/03/2001', 4680000, N'Defender', 'Right'),
(1007, 6, N'Thiago Silva', 'thiagosilva.png',N'Brazil', 1.83, 79, '22/09/1984', 5720000, N'Defender', 'Right'),
(1007, 14, N'Trevoh Chalobah', null,N'England', 1.90, 75, '05/07/1999', 2600000, N'Defender', 'Right'),
(1007, 21, N'Ben Chilwell ', null,N'England', 1.78, 77, '21/12/1996', 10400000, N'Defender', 'Left'),
(1007, 24, N'Reece James', 'reecejames.png',N'England', 1.82, 82, '08/12/1999', 13000000, N'Defender', 'Right'),
(1007, 26, N'Levi Colwill', null,N'England', 1.87, 83, '26/02/2003', 260000, N'Defender', null),
(1007, 27, N'Malo Gusto', null,N'France', 1.79, 67, '19/05/2003', 0, N'Defender', 'Right'),
(1007, 29, N'Ian Maatsen', null,N'Netherlands', 1.67, 57, '10/03/2002', 0, N'Defender', 'Left'),
(1007, 33, N'Wesley Fofana', null,N'France', 1.90, 84, '17/12/2000', 10400000, N'Defender', 'Right'),
(1007, 42, N'Alfie Gilchrist', null,N'England', 1.83, null, '28/11/2003', 0, N'Defender', null),
(1007, 48, N'Bashir Humphreys', null,N'England', 1.87, 79, '15/03/2003', 0, N'Defender', 'Right'),
(1007, null, N'Malang Sarr', null,N'France', 1.83, 73, '23/01/1999', 6240000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1007, 8, N'Enzo Fernández', 'enzofernandez.png',N'Argentina', 1.78, 76, '17/01/2001', 9360000, N'Midfielder', 'Right'),
(1007, 16, N'Lesley Ugochukwu', 'lesleyugochukwu.png',N'France', 1.88, null, '26/03/2004', 0, N'Midfielder', null),
(1007, 17, N'Carney Chukwuemeka', 'carneychukwuemeka.png',N'England', 1.87, 77, '20/10/2003', 5200000, N'Midfielder', null),
(1007, 23, N'Conor Gallagher', null,N'England', 1.82, 77, '06/02/2000', 2600000, N'Midfielder', 'Right'),
(1007, 25, 'Moisés Caicedo', null,N'Ecuador', 1.73, 68, '02/11/2001', 7800000, N'Midfielder', 'Right'),
(1007, 45, 'Roméo Lavia', null,N'Belgium', 1.81, null, '06/01/2004', 2340000, N'Midfielder', 'Right'),

-------------------Forwards-------------------
(1007, 7, N'Raheem Sterling', 'sterling.png',N'England', 1.72, 69, '08/12/1994', 16900000, N'Forward', 'Right'),
(1007, 10, N'Mykhailo Mudryk', 'mykhailomudryk.png',N'Ukraine', 1.75, 61, '05/01/2001', 5200000, N'Forward', 'Right'),
(1007, 11, N'Noni Madueke', 'nonimadueke.png',N'England', 1.76, 75, '10/03/2002', 2600000, N'Forward', 'Left'),
(1007, 15, N'Nicolas Jackson', null,N'Senegal', 1.86, 78, '20/06/2001', 0, N'Forward', 'Right'),
(1007, 18, N'Christopher Nkunku', null,N'France', 1.78, 68, '14/11/1997', 10140000, N'Forward', 'Right'),
(1007, 19, N'Armando Broja', null,N'Albania', 1.91, 83, '10/09/2001', 2080000, N'Forward', 'Right'),
(1007, 20, N'Cole Palmer', 'colepalmer.png',N'England', 1.82, 74, '06/05/2002', 2080000, N'Forward', 'Left'),
(1007, 36, N'Deivid Washington', null,N'Brazil', 1.87, null, '05/06/2005', 364000, N'Forward', null),
(1007, 37, N'Mason Burstow', null,N'England', 1.88, 79, '04/08/2003', 0, N'Forward', null),
(1026, 43, N'Diego Moreira', null,N'Portugal', 1.79, 73, '06/08/2004', 0, N'Forward', null),
(1007, 52, N'Alex Matos', null,N'England', null, null, '03/10/2004', 0, N'Forward', null),
(1007, 62, N'Ronnie Stutter', null,N'England', null, null, '06/01/2005', 0, N'Forward', null)


--7. CRYSTAL PALACE-------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1008, 1, N'Sam Johnstone', null, N'England', 1.93, 85, '25/03/1993', 2080000, N'Goalkeeper', 'Right'),
(1008, 30, 'Dean Henderson', 'deanhenderson.png', 'England', 1.88, 85, '12/03/1997', 0, N'Goalkeeper', 'Right'),
(1008, 31, N'Remi Matthews', null, N'England', 1.84, 78, '10/04/1994', 280000, N'Goalkeeper', 'Right'),
(1008, 41, N'Joe Whitworth', null, N'England', null, null, '29/02/2004', 0, N'Goalkeeper', null),

-------------------Defenders-------------------
(1008, 2, N'Joel Ward', 'joelward.png', N'England', 1.88, 83, '29/10/1989', 1820000, N'Defender', 'Right'),
(1008, 3, N'Tyrick Mitchell', null, N'England', 1.75, 68, '01/09/1999', 2080000, N'Defender', null),
(1008, 4, 'Rob Holding', 'robholding.png', N'England', 1.89, 75, '20/09/1995', 0, N'Defender', N'Right'),
(1008, 5, N'James Tomkins', null, N'England', 1.92, 74, '29/03/1989', 2600000, N'Defender', 'Right'),
(1008, 6, N'Marc Guéhi', null, N'England', 1.82, 82, '13/07/2000', 2600000, N'Defender', 'Right'),
(1008, 16, N'Joachim Andersen', null, N'Denmark', 1.92, 90, '31/05/1996', 4160000, N'Defender', 'Right'),
(1008, 17, N'Nathaniel Clyne', null, N'England', 1.75, 67, '05/04/1991', 4160000, N'Defender', 'Right'),
(1008, 26, N'Chris Richards', 'chrisrichards.png', N'USA', 1.88, 87, '28/03/2000', 2860000, N'Defender', 'Right'),
(1008, 36, N'Nathan Ferguson', null, N'England', 1.78, 74, '06/10/2000', 1300000, N'Defender', null),
(1008, 42, 'Seán Grehan', null, N'Republic of Ireland', null, null, '08/01/2004', 0, N'Defender', null),

-------------------Midfielders-------------------
(1008, 7, N'Michael Olise', 'michaelolise.png', N'France', 1.84, 76, '12/12/2001', 2340000, N'Midfielder', null),
(1008, 8, N'Jefferson Lerma', null, N'Colombia', 1.79, 70, '25/10/1994', 0, N'Midfielder', 'Right'),
(1008, 10, N'Eberechi Eze', 'eberechieze.png', N'England', 1.78, 74, '26/06/1998', 1560000, N'Midfielder', null),
(1008, 15, N'Jeffrey Schlupp', null, N'Ghana', 1.78, 72, '23/12/1992', 2600000, N'Midfielder', 'Both'),
(1008, 19, N'Will Hughes', 'willhughes.png', N'England', 1.85, 74, '17/04/1995', 1820000, N'Midfielder', 'Left'),
(1008, 23, N'Malcolm Ebiowei', null, N'England', 1.85, NULL, '04/09/2003', NULL, N'Midfielder', 'Left'),
(1008, 28, N'Cheick Doucouré', null, N'Mali', 1.80, 73, '08/01/2000', 3120000, N'Midfielder', 'Right'),
(1008, 29, N'Naouirou Ahamada', null, N'France', 1.83, 73, '29/03/2002', 1040000, N'Midfielder', null),
(1008, 40, N'Jack Wells-Morrison', null, N'England', null, null, '18/02/2004', null, N'Midfielder', null),
(1008, 44, N'Jairo Riedewald', null, N'Netherlands', 1.82, 79, '09/09/1996', 2860000, N'Midfielder', 'Left'),
(1008, 49, N'Jesurun Rak-Sakyi', null, N'England', null, null, '05/10/2002', null, N'Midfielder', null),
(1008, 60, N'Jadan Raymond', null, N'Wales', null, null, '15/10/2003', null, N'Midfielder', null),
(1008, 77, N'David Ozoh', null, N'England', null, null, '06/05/2005', null, N'Midfielder', null),

-------------------Forwards-------------------
(1008, 9, N'Jordan Ayew', 'jordanayew.png', N'Ghana', 1.82, 80, '11/09/1991', 1820000, N'Forward', 'Right'),
(1008, 11, N'Matheus França', 'matheusfranca.png', N'Brazil', null, null, '01/04/2004', 0, N'Forward', 'Right'),
(1008, 14, N'Jean-Philippe Mateta', 'mateta.png', N'France', 1.92, 88, '28/06/1997', 2600000, N'Forward', 'Right'),
(1008, 22, N'Odsonne Édouard', null, N'France', 1.87, 83, '16/01/1998', 4680000, N'Forward', 'Right'),
(1026, 37, N'John-Kymani Gordon', null, N'France', null, null, '13/02/2003', 0, N'Forward', null),
(1008, 53, N'Ademola Ola-Adebomi', null, N'England', null, null, '03/09/2003', 0, N'Forward', null)


--8. EVERTON--------------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1009, 1, N'Jordan Pickford', 'pickford.png','England', 1.85, 82, '07/03/1994', 6500000, N'Goalkeeper', 'Left'),
(1009, 12, N'João Virgínia', null,'Portugal', 1.93, 83, '10/10/1999', 390000, N'Goalkeeper', 'Left'),
(1009, 31, N'Andy Lonergan', null,'England', 1.92, 87, '19/10/1983', 520000, N'Goalkeeper', 'Left'),
(1009, 43, N'Billy Crellin', null,'England', 1.85, 60, '30/06/2000', 520000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1009, 2, N'Nathan Patterson', null,'Scotland', 1.89, 83, '16/10/2001', 1456000, N'Defender', 'Right'),
(1009, 4, N'Mason Holgate', null,'England', 1.84, 63, '22/10/1996', 1040000, N'Defender', 'Right'),
(1009, 5, N'Michael Keane', 'michaelkeane.png','England', 1.91, 82, '11/01/1993', 4160000, N'Defender', 'Right'),
(1009, 6, N'James Tarkowski', 'tarkowski.png','England', 1.92, 87, '19/10/1983', 5200000, N'Defender', 'Right'),
(1009, 18, N'Ashley Young', 'ashleyyoung.png', N'England', 1.75, 65, '09/07/1985',0, N'Defender', 'Both'),
(1009, 19, N'Vitaliy Mykolenko', null,'Ukraine', 1.80, 71, '29/05/1999', 3016000, N'Defender', 'Right'),
(1009, 22, N'Ben Godfrey', null,'England', 1.83, 74, '15/01/1998', 3900000, N'Defender', 'Right'),
(1009, 23, N'Séamus Coleman', null,'Republic of Ireland', 1.77, 67, '11/10/1988', 2860000, N'Defender', 'Right'),
(1009, 32, N'Jarrard Branthwaite', null,'England', 1.95, 67, '27/06/2002', 780000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1009, 8, N'Amadou Onana', 'amudouonana.png','Belgium', 1.92, 76, '16/08/2001', 5200000, N'Midfielder', 'Both'),
(1009, 16, N'Abdoulaye Doucouré', 'doucoure.png','Mali', 1.84, 75, '01/01/1993', 6240000, N'Midfielder', 'Right'),
(1009, 20, N'Dele Alli', 'delealli.png','England', 1.88, 76, '11/04/1996', 5200000, N'Midfielder', 'Right'),
(1009, 21, N'André Gomes', 'andregomes.png','Portugal', 1.88, 84, '30/07/1993', 5840000, N'Midfielder', 'Right'),
(1009, 25, N'Jean-Philippe Gbamin', null,'Côte dIvoire', 1.86, 83, '25/09/1995', 3900000, N'Midfielder', 'Right'),
(1009, 27, N'Idrissa Gueye', null,'Senegal', 1.74, 66, '26/09/1989', 4160000, N'Midfielder', 'Right'),
(1009, 37, N'James Garner', null,'England', 1.86, 78, '13/03/2001', 1560000, N'Midfielder', 'Right'),
(1009, 58, N'Mackenzie Hunt', null,N'England', null, null, '14/11/2001', 0, N'Midfielder', null),
(1009, 62, N'Tyler Onyango', null,'England', null, null, '04/03/2004', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1009, null, N'Jack Harrison', 'jackharrison.png','England', 1.75, 70, '20/10/1996', 0, N'Forward', null),
(1009, 7, N'Dwight McNeil', null,'England', 1.83, 68, '22/11/1999', 1300000, N'Forward', 'Left'),
(1009, 9, N'Dominic Calvert-Lewin', null,'England', 1.87, 71, '16/03/1997', 5200000, N'Forward', 'Right'),
(1009, 10, N'Arnaut Danjuma', null,'Netherlands', 1.78, 74, '31/01/1997', 2730000, N'Forward', 'Both'),
(1009, 11, N'Demarai Gray', null,'England', 1.80, 74, '28/06/1996', 1300000, N'Forward', 'Both'),
(1009, 14, N'Beto', 'beto.png','Portugal', 1.94, 88, '31/01/1998', 2600000, N'Forward', 'Right'),
(1009, 28, N'Youssef Chermiti', null,'Portugal', 1.92, 84, '24/05/2004', 0, N'Forward', 'Right'),
(1009, 47, N'Thomas Cannon', null,'Ireland', null, null, '28/12/2002', 390000, N'Forward', null),
(1009, 61, N'Lewis Dobbin', 'lewisdobbin.png','England', null, null, '03/01/2003', 0, N'Forward', null)


--9. FULLHAM FC--------------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1010, 1, N'Marek Rodák', null, 'Slovakia', 1.94, 81, '13/12/1996', 780000, N'Goalkeeper', 'Right'),
(1010, 17, N'Bernd Leno', 'berndleno.png', N'Germany', 1.89, 82, '04/03/1992', 4680000, N'Goalkeeper', 'Right'),
(1010, 23, N'Steven Benda', null, N'Germany', 1.92, 83, '01/10/1998', 0, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1010, 2, N'Kenny Tete', 'kennytete.png', N'Netherlands', 1.80, 71, '09/10/1995', 2600000, N'Defender', 'Right'),
(1010, 3, N'Calvin Bassey', 'calvinbassey.png', N'Nigeria', 1.85, 76, '31/12/1999', 0, N'Defender', 'Left'),
(1010, 4, N'Tosin Adarabioyo', null, 'England', 1.96, 80, '24/09/1997', 2080000, N'Defender', 'Right'),
(1010, 12, N'Fodé Ballo-Touré', null, N'Defender', 1.82, 70, '03/01/1997', 1690000, N'Defender', 'Left'),
(1010, 13, N'Tim Ream', 'timream.png', N'USA', 1.83, 80, '05/10/1987', 1560000, N'Defender', 'Left'),
(1010, 21, N'Timothy Castagne', null, N'Belgium', 1.85, 80, '05/12/1995', 0, N'Defender', 'Right'),
(1010, 27, N'Kevin Mbabu', null, N'Sweden', 1.84, 83, '19/04/1995', 2080000, N'Defender', 'Right'),
(1010, 31, N'Issa Diop', null, N'France', 1.94, 92, '09/01/1997', 3640000, N'Defender', 'Right'),
(1010, 33, N'Antonee Robinson', null, N'USA', 1.83, 70, '08/08/1997', 2600000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1010, 6, N'Harrison Reed', 'harrisonreed.png', N'England', 1.81, 72, '27/01/1995', 1560000, N'Midfielder', 'Right'),
(1010, 10, N'Tom Cairney', 'tomcairney.png', N'Scotland', 1.83, 72, '20/01/1991', 1560000, N'Midfielder', 'Left'),
(1010, 18, N'Andreas Pereira', null, N'Brazil', 1.78, 71, '01/01/1996', 1560000, N'Midfielder', 'Right'),
(1010, 22, N'Alex Iwobi', 'alexiwobi.png', 'Nigeria', 1.80, 75, '03/05/1996', 0, N'Midfielder', 'Right'),
(1010, 26, N'João Palhinha', null, N'Portugal', 1.90, 84, '09/07/1995', 2600000, N'Midfielder', 'Right'),
(1010, 28, N'Sasa Lukić', null, N'Sebria', 1.83, 76, '13/08/1996', 676000, N'Midfielder', 'Right'),
(1010, 35, N'Tyrese Francois', null, N'Australia', 1.70, 60, '16/07/2000', 676000, N'Midfielder', null),
(1010, 38, N'Luke Harris', null, N'Wales', 1.77, null, '04/03/2005', 0, N'Midfielder', 'Right'),
(1010, 49, N'Matthew Dibley-Dias', null, N'England', null, null, '29/10/2003', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1010, 7, N'Raúl Jiménez', null, N'Mexico', 1.90, 76, '05/05/1991', 5200000, N'Forward',  'Right'),
(1010, 8, N'Harry Wilson', 'harrywilson.png', N'Wales', 1.73, 63, '22/03/1997', 1820000, N'Forward', 'Left'),
(1010, 9, N'Aleksandar Mitrović', null, N'Sebria', 1.89, 89, '16/09/1994', 4160000, N'Forward', 'Right'),
(1010, 11, N'Adama Traoré', null, N'Spain', 1.78, 86, '25/01/1996', 0, N'Tiền đạo',  N'Chân phải'),
(1010, 14, N'Bobby De Cordova-Reid', null, N'Jamaica', 1.70, 68, '02/02/1993', 1820000, N'Forward', 'Right'),
(1010, 19, N'Rodrygo Muniz', 'rodrigomuniz.png', N'Brazil', 1.78, null, '04/05/2001', 3432000, N'Forward', 'Right'),
(1010, 20, N'Willian', 'willian.png', N'Brazil', 1.77, 75, '09/08/1988', 1820000, N'Forward', 'Right'),
(1010, 30, N'Carlos Vinícius', null, N'Brazil', 1.90, 86, '25/03/1995', 2080000, N'Forward', 'Left'),
(1010, 65, N'Jay Stansfield', null, N'England', null, null, '24/11/2002', 0, N'Forward', null)

--10. LEEDS UNITED--------------------------------------------------------------------
-------------------Goalkeepers-------------------
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES
(1014, 1, N'Illan Meslier', null, N'France', 1.97, 74, '02/03/2002', 1560000, N'Goalkeeper', N'Right'),
(1014, 13, N'Kristoffer Klaesson', null, N'Norway', 1.89, 76, '27/11/2000', 520000, N'Goalkeeper', null),
(1014, 22, N'Joel Robles', 'joelrobles.png', N'Spain', 1.95, 78, '17/06/1990', 1040000, N'Goalkeeper', N'Right'),

-------------------Defenders-------------------
(1014, 2, N'Luke Ayling', 'lukeayling.png', N'England', 1.85, 72, '25/08/1991', 1300000, N'Defender', N'Right'),
(1014, 3, N'Junior Firpo', null, N'Spain', 1.84, 78, '22/08/1996', 3120000, N'Defender', N'Left'),
(1014, 5, N'Robin Koch', null, N'Germany', 1.92, 85, '17/07/1996', 2080000, N'Defender', N'Right'),
(1014, 6, N'Liam Cooper', 'liamcooper.png', N'Scotland', 1.80, 73, '30/08/1991', 1300000, N'Defender', N'Left'),
(1014, 15, N'Stuart Dallas', null, N'Northern Ireland', 1.83, 81, '19/04/1991', 2340000, N'Defender', N'Right'),
--(1014, 21, N'Junior Firpo', N'Netherlands', 1.90, 79, '11/08/1999', 2600000, N'Defender', N'Left'),
(1014, 25, N'Rasmus Kristensen', null, N'Denmark', 1.87, 70, '11/07/1997', 2080000, N'Defender', N'Right'),
(1014, 39, N'Maximilian Wöber', 'maximilianwober.png', N'Austria', 1.88, 85, '04/02/1998', 1820000, N'Defender', N'Left'),
(1014, 14, N'Diego Llorente', null, N'Spain', 1.86, 75, '16/08/1993', 1040000, N'Defender', N'Right'),
(1014, 33, N'Leo Hjelde', null, N'Norway', 1.88, null, '26/08/2003', 52000, N'Defender', N'Left'),
(1014, 37, N'Cody Drameh', null, N'England', 1.75, null, '08/12/2001', 228800, N'Defender', N'Right'),
(1014, 18, N'Darko Gyabi', null, N'England', 1.94, null, '18/02/2004', 228800, N'Defender', null),

-------------------Midfielders-------------------
(1014, 4, N'Adam Forshaw', 'adamforshaw.png', N'England', 1.74, 71, '08/10/1991', 1040000, N'Midfielder', N'Right'),
(1014, 7, N'Brenden Aaronson', null, N'USA', 1.78, 70, '20/10/2000', 2340000, N'Midfielder', N'Right'),
(1014, 8, N'Marc Roca', null, N'Netherlands', 1.84, 77, '26/11/1996', 2600000, N'Midfielder', N'Left'),
(1014, 28, N'Weston McKennie', null, N'USA', 1.83, 84, '28/08/1998', 3900000, N'Midfielder', N'Right'),
(1014, 42, N'Sam Greenwood', 'samgreenwood.png', N'England', 1.85, null, '26/01/2002', 1560000, N'Midfielder', null),
(1014, 43, N'Mateusz Klich', null, N'Poland', 1.83, 84, '13/06/1990', 1768000, N'Midfielder', N'Right'),
(1014, 63, N'Archie Gray', 'archiegray.png', N'England', null, null, '12/03/2006', null, N'Midfielder',null),

-------------------Forwards-------------------
(1014, 9, N'Patrick Bamford', null, N'England', 1.85, 71, '05/09/1993', 3640000, N'Forward', N'Left'),
(1014, 10, N'Crysencio Summerville', 'crysenciosummerville.png', N'Netherlands', 1.74, null, '30/10/2001', 780000, N'Forward', N'Right'),
(1014, 19, N'Rodrigo', 'rodrigo.png', N'Spain', 1.82, 77, '06/03/1991', 5200000, N'Forward', N'Left'),
(1014, 24, N'Georginio Rutter', null, N'France', 1.82, 83, '20/04/2002', 3640000, N'Forward', null),
(1014, 29, N'Wilfried Gnonto', null, N'Italy', 1.72, 65, '05/11/2003', 1040000, N'Forward', N'Right'),
(1014, 30, N'Joe Gelhardt', 'joegelhardt.png', N'England', 1.75, 65, '04/05/2002', null, N'Forward', N'Left')

--12. LIVERPOOL-----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES
(1012, 1, 'Alisson Becker', 'allison.png', 'Brazil', 1.93, 91, '1992-02-10', 7800000, N'Goalkeeper', 'Right'),
(1012, 13, 'Adrian', null, N'Spain', 1.88, 80, '1987-01-03', 3120000, N'Goalkeeper', 'Right'),
(1012, 45, 'Marcelo Pitaluga', null, 'Brazil', null, null, '2002-12-20', 0, N'Goalkeeper', null),
(1012, 62, 'Caoimhin Kelleher', null, 'Ireland', 1.78, 75, '1998-11-23', 520000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1012, 2, 'Joe Gomez', 'gomez.png', 'England', 1.88, 77, '1997-05-23', 4420000, N'Defender', 'Right'),
(1012, 4, 'Virgil van Dijk', 'vandijk.png', N'Netherlands', 1.95, 90, '1991-07-08', 11400000, N'Defender', 'Right'),
(1012, 5, 'Ibrahima Konate', 'konate.png', N'France', 1.93, 84, '1999-05-25', 3640000, N'Defender', 'Right'),
(1012, 21, 'Konstantinos Tsimikas', 'tsimikas.png', 'Scotland', 1.78, 77, '1996-05-12', 2600000, N'Defender', 'Left'),
(1012, 26, 'Andrew Robertson', 'robertson.png', 'Scotland', 1.78, 64, '1998-11-03', 5200000, N'Defender','Left'),
(1012, 32, 'Joel Matip', 'matip.png', 'Cameroon', 1.95, 90, '1991-08-08', 5200000, N'Defender', 'Right'),
(1012, 47, 'Nathaniel Phillips', null, 'England', 1.88, 76, '1997-03-21', 3380000, N'Defender', 'Right'),
(1012, 66, 'Trent Alexander-Arnold', 'arnold.png', 'England', 1.75, 72, '1998-10-07', 9360000, N'Defender', 'Right'),
(1012, 78, 'Jarell Quansah', null, 'England', NULL, NULL, '2003-01-29', 0, N'Defender', NULL),

-------------------Midfielders-------------------
(1012, 3, 'Wataru Endo', 'endo.png', N'Japan', 1.78, 77, '1993-09-02', 2600000, N'Midfielder', 'Right'),
(1012, 6, 'Thiago Alcantara', null, N'Spain', 1.74, 70, '1991-11-04', 10400000, N'Midfielder', 'Right'),
(1012, 8, 'Dominik Szoboszlai', 'szoboszlai.png', 'Hungary', 1.86, 74, '2000-10-25', 6240000, N'Midfielder', 'Right'),
(1012, 10, 'Alexis Mac Allister', 'allister.png', 'Argentina', 1.76, 69, '1998-12-24', 7800000, N'Midfielder', 'Right'),
(1012, 17, 'Curtis Jones', null, 'England', 1.85, 81, '2001-01-30', 780000, N'Midfielder', 'Right'),
(1012, 19, 'Harvey Elliot', 'elliot.png', 'England', 1.70, 65, '2003-04-04', 2080000, N'Midfielder', 'Left'),
(1012, 38, 'Ryan Gravenberch', 'gravenberch.png', 'Netherlands', 1.90, 83, '2002-05-16', 7800000, N'Midfielder', 'Right'),
(1012, 43, N'Stefan Bajčetić', null, N'Spain', 1.85, 77, '2004-10-22', 2080000, N'Midfielder', null),
(1012, 53, N'James McConnell', null, N'England', NULL, null, '2004-09-13', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1012, 7, 'Luis Diaz', 'diaz.png', 'Colombia', 1.78, 65, '1997-01-13', 2860000, N'Forward', 'Right'),
(1012, 9, 'Darwin Nunez', 'nunez.png', 'Uruguay', 1.88, 78, '1999-06-24', 7280000, N'Forward', 'Right'),
(1012, 11, 'Mohamed Salah', 'salah.png', N'Egypt', 1.75, 71, '1992-06-15', 18200000, N'Forward', 'Left'),
(1012, 18, 'Cody Gakpo', null, N'Netherlands', 1.93, 65, '1999-05-07', 6240000, N'Forward', 'Right'),
(1012, 20, 'Diogo Jota', 'jota.png', N'Portugal', 1.70, 65, '1996-12-04', 7280000, N'Forward', 'Right'),
(1012, 50, 'Ben Doak', null, N'Scotland', null, null, '2005-11-11', 0, N'Forward', null);


--13. LUTON TOWN FC-----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1013, 1, 'James Shea', 'jamesshea.png', 'England', 1.85, 76, '16/09/1991', 180000, N'Goalkeeper', null),
(1013, 23, 'Tim Krul', null, 'Netherlands', 1.88, 84, '03/04/1988', 0, N'Goalkeeper', 'Left'),
(1013, 24, 'Thomas Kaminski', null, 'Belgium', 1.90, 78, '23/10/1992', 90000, N'Goalkeeper', 'Both'),
(1013, 33, 'Matt Macey', null, 'England', 2.02, 96, '09/09/1994', 90000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1013, 2, 'Gabriel Osho', 'gabrielosho.png', 'England', null, null, '14/08/1998', 260000, N'Defender', 'Right'),
(1013, 3, 'Daniel Potts', null, 'England', 1.73, 76, '13/04/1994', 0, N'Defender', 'Left'),
(1013, 4, 'Tom Lockyer', null, 'Wales', 1.85, 72, '03/12/1994', 420000, N'Defender', 'Right'),
(1013, 5, 'Mads Andersen', null, N'Denmark', 1.94, 81, '27/12/1997', 0, N'Defender', 'Right'),
(1013, 12, 'Issa Kaboré', null, 'Burkina Faso', 1.80, null, '12/05/2001', 0, N'Defender', 'Right'),
(1013, 15, 'Teden Mengi', 'tedenmengi.png', N'England', 1.83, 78, '30/04/2002', 0, N'Defender', 'Right'),
(1013, 16, 'Reece Burke', null, 'England', 1.88, 81, '02/09/1996', 390000, N'Defender', 'Right'),
(1013, 29, 'Amarii Bell', 'amariiBell.png', 'Jamaica', 1.80, 66, '05/05/1994', 320000, N'Defender', 'Left'),
(1013, 38, 'Joseph Johnson', null, 'England', null, null, '09/01/2006', 0, N'Defender', null),
(1013, 40, 'Aidan Francis-Clarke', null, N'England', null, null, '13/09/2005', 0, N'Defender', null),
(1013, 45, 'Alfie Doughty', 'alfiedoughty.png', 'England', 1.83, null, '21/12/1999', 170000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1013, 6, 'Ross Barkley', 'rossbarkley.png', 'England', 1.89, 76, '05/12/1993', 0, N'Midfielder', 'Right'),
(1013, 8, 'Luke Berry', null, 'England', 1.77, 72, '12/07/1992', 260000, N'Midfielder', 'Right'),
(1013, 13, 'Marvelous Nakamba', null, 'Zimbabwe', 1.78, 71, '19/01/1994', 0, N'Midfielder', 'Left'),
(1013, 14, 'Tahith Chong', null, 'England', 1.85, 75, '04/12/1999', 0, N'Midfielder', 'Left'),
(1013, 17, 'Pelly-Ruddock Mpanzu', null, 'DR Congo', 1.75, 63, '22/03/1994', 160000, N'Midfielder', 'Right'),
(1013, 18, 'Jordan Clark', 'jordanclark.png', 'England', 1.83, 71, '22/09/1993', 120000, N'Midfielder', 'Right'),
(1013, 20, 'Louie Watson', null, 'Ireland', null, null, '07/06/2001', 120000, N'Midfielder', null),
(1013, 22, 'Allan Campbell', null, 'Scotland', 1.75, 73, '04/07/1998', 440000, N'Midfielder', 'Right'),
(1013, 26, 'Ryan Giles', null, 'England', 1.79, 72, '26/01/2000', 0, N'Midfielder', null),
(1013, 30, 'Luke Freeman', null, 'England', 1.81, 64, '22/03/1992', 110000, N'Midfielder', 'Left'),
(1013, 42, 'Casey Pettit', null, 'England', null, null, '15/10/2002', 0, N'Midfielder', null),
(1013, 28, N'Albert Lokonga', 'albertsambilokonga.png', N'Belgium', 1.73, 67, '22/10/1999', 2600000, N'Midfielder', 'Right'),

-------------------Forwards-------------------
(1013, 7, 'Chiedozie Ogbene', null, 'Ireland', 1.81, 78, '01/05/1997', 0, N'Forward', 'Right'),
(1013, 9, 'Carlton Morris', 'carltonmorris.png', 'England', 1.85, 85, '16/12/1995', 260000, N'Forward', 'Right'),
(1013, 10, 'Cauley Woodrow', null, 'England', 1.84, 78, '02/12/1994', 420000, N'Forward', 'Right'),
(1013, 11, 'Elijah Adebayo', 'elijahadebayo.png', 'England', 1.93, 89, '02/12/1994', 390000, N'Forward', null),
(1013, 15, 'Admiral Muskwe', null, 'Zimbabwe', 1.83, null, '21/08/1998', 230000, N'Forward', null),
(1013, 19, 'Jacob Brown', null, 'Scotland', 1.78, 62, '10/04/1998', 0, N'Forward', 'Right'),
(1013, 21, 'John McAtee', null, 'England', 1.80, 75, '23/07/1999', 150000, N'Forward', null),
(1013, 25, 'Joe Taylor', null, 'Wales', null, null, '18/11/2002', 52000, N'Forward', null),
(1013, 27, 'Aribim Pepple', null, 'Canada', 1.85, 83, '25/12/2002', 52000, N'Forward', null)


--14. MAN CITY-----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1015, 18, 'Stefan Ortega', null,N'Germany', 1.85, 88, '06/11/1992', 2860000, N'Goalkeeper', 'Right'),
(1015, 13, 'Zack Steffen', null,N'USA', 1.91, 86, '02/04/1995', 2392000, N'Goalkeeper', 'Right'),
(1015, 31, 'Ederson', 'ederson.png','Brazil', 1.88, 89, '17/08/1993', 5200000, N'Goalkeeper', 'Left'),
(1015, 33, 'Scott Carson', null,'England', 1.88, 85, '03/09/1985', 1560000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1015, 2, 'Kyle Walker', 'kylewalker.png','England', 1.78, 80, '28/05/1990', 8320000, N'Defender', 'Right'),
(1015, 3, N'Rúben Dias', 'rubendias.png',N'Portugal', 1.86, 76, '14/05/1997', 9360000, N'Defender', 'Right'),
(1015, 5, 'John Stones', null,'England', 1.88, 80, '28/05/1994', 13000000, N'Defender', 'Right'),
(1015, 6, N'Nathan Aké', 'nathanake.png',N'Netherlands', 1.80, 75, '18/02/1995', 4680000, N'Defender', 'Left'),
(1015, 14, 'Aymeric Laporte', null,N'Spain', 1.89, 86, '27/05/1994', 6240000, N'Defender', N'Left'),
(1015, 21, 'Sergio Gómez', null,N'Spain', 1.71, 68, '04/09/2000', 2600000, N'Defender', 'Left'),
(1015, 24, 'Josko Gvardiol',null, N'Croatia', 1.85, 80, '23/01/2002', 10400000, N'Defender', 'Left'),
(1015, 25, 'Manuel Akanji', null,N'Switzerland', 1.86, 91, '19/07/1995', 9360000, N'Defender', 'Right'),
(1015, 52, 'Oscar Bobb', null,'Norway', null, null, '12/07/2003', 0, N'Defender', null),
(1015, 82, 'Rico Lewis', null,'England', 1.69, null, '21/11/2004', 260000, N'Defender', null),
(1015, 78, 'Taylor Harwood-Bellis', null,'England', 1.88, null, '30/01/2002', 390000, N'Defender', 'Right'),

-------------------Midfielders-------------------
(1015, 4, 'Kalvin Phillips', null,'England', 1.78, 72, '02/12/1995', 7800000, N'Midfielder', 'Right'),
(1015, 8, N'Mateo Kovačić', null,N'Croatia', 1.77, 78, '06/05/1994', 7800000, N'Midfielder', 'Right'),
(1015, 10, 'Jack Grealish', null,'England', 1.75, 76, '10/09/1995', 15600000, N'Midfielder', 'Right'),
(1015, 11, 'Jérémy Doku', 'doku.png',N'Belgium', 1.73, 66, '27/05/2002', 2600000, N'Midfielder', 'Right'),
(1015, 16, N'Rodrígo', 'rodri.png',N'Spain', 1.90, 82, '22/06/1996', 11440000, N'Midfielder', 'Right'),
(1015, 17, 'Kevin De Bruyne', 'debruyne.png',N'Belgium', 1.81, 68, '28/06/1991', 20800000, N'Midfielder', 'Right'),
(1015, 20, 'Bernardo Silva', 'bernardosilva.png',N'Portugal', 1.73, 64, '10/08/1994', 7800000, N'Midfielder', 'Left'),
(1015, 27, N'Matheus Nunes', null,N'Portugal', 1.84, 78, '27/08/1998', 0, N'Midfielder', 'Right'),
(1026, 32, 'Máximo Perrone', null,'Argentina', 1.78, 64, '07/01/2003', 1560000, N'Midfielder', 'Left'),
(1015, 47, 'Phil Foden', null,'England', 1.71, 70, '28/05/2000', 11700000, N'Midfielder', 'Left'),
(1015, 96, 'Ben Knight', null,'England', 1.71, null, '14/06/2002', null, N'Midfielder', null),

-------------------Forwards-------------------
(1015, 9, 'Erling Haaland', 'haaland.png',N'Netherlands', 1.94, 88, '21/07/2000', 19500000, N'Forward', 'Left'),
(1015, 19, 'Julián Álvarez', 'alvarez.png','Argentina', 1.70, 71, '31/01/2000', 5200000, N'Forward', 'Right')


--14. MAN UNITED----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1016, 1, 'Altay Bayindir', null,'Turkey', 1.98, 88, '14/04/1998', 0, N'Goalkeeper', 'Both'),
(1016, 22, 'Tom Heaton', null,'England', 1.88, 85, '15/04/1986', 2340000, N'Goalkeeper', 'Right'),
(1016, 24, 'André Onana', 'onana.png','Cameroon', 1.90, 93, '02/04/1996', 6240000, N'Goalkeeper', 'Right'),
(1016, 40, 'Radek Vítek', null,'Czechia', 1.98, NULL, '24/10/2003', 0, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1016, 2, 'Victor Lindelöf', null,N'Sweden', 1.87, 80, '17/07/1994', 6240000, N'Defender', 'Right'),
(1016, 5, 'Harry Maguire', 'maguire.png','England', 1.94, 90, '05/03/1993', 9880000, N'Defender', 'Right'),
(1016, 6, 'Lisandro Martínez', null,'Argentina', 1.75, 77, '18/01/1998', 6240000, N'Defender', 'Left'),
(1016, 12, 'Tyrell Malacia', 'tyrellmalacia.png',N'Netherlands', 1.70, 67, '17/08/1999', 3900000, N'Defender', 'Left'),
(1016, 15, N'Sergio Reguilón',null, N'Spain', 1.78, 68, '16/12/1996', 2756000, N'Defender', 'Left'),
(1016, 19, N'Raphaël Varane', null,N'France', 1.91, 81, '24/04/1993', 17680000, N'Defender', 'Right'),
(1016, 20, 'Diogo Dalot', 'diogodalot.png',N'Portugal', 1.83, 76, '18/03/1999', 4420000, N'Defender', 'Right'),
(1016, 23, 'Luke Shaw', null,'England', 1.85, 75, '12/07/1995', 7800000, N'Defender', 'Left'),
(1016, 29, 'Aaron Wan-Bissaka', null,'England', 1.83, 72, '26/11/1997', 4680000, N'Defender', 'Right'),
(1016, 33, 'Brandon Williams', null,N'England', 1.71, 63, '03/09/2000', 3380000, N'Defender', 'Right'),
(1016, 35, 'Jonny Evans', null,N'Northern Ireland', 1.88, 77, '03/01/1988', 0, N'Defender', 'Both'),
(1016, 42, 'Alvaro Fernandez', null,N'Spain', null, null, '23/03/2003', 0, N'Defender', null),

-------------------Midfielders-------------------
(1016, 4, N'Sofyan Amrabat', null,N'Morocco', 1.83, 70, '21/08/1996', 3380000, N'Midfielder', 'Right'),
(1016, 7, N'Mason Mount', null,N'England', 1.81, 76, '10/01/1999', 10400000, N'Midfielder', 'Right'),
(1016, 8, 'Bruno Fernandes', 'bruno.png',N'Portugal', 1.79, 69, '08/09/1994', 12480000, N'Midfielder', 'Right'),
(1016, 14, 'Christian Eriksen', 'christianeriksen.png',N'Denmark', 1.82, 76, '14/02/1992', 7800000, N'Midfielder', 'Both'),
(1016, 16, 'Amad Diallo', null,N'Côte dIvoire', 1.73, 72, '12/07/2002', 1500000, N'Midfielder', 'Right'),
(1016, 18, 'Casemiro', 'casemiro.png','Brazil', 1.85, 84, '23/02/1992', 18200000, N'Midfielder', 'Right'),
(1016, 28, 'Facundo Pellistri', null,'Uruguay', 1.75, 69, '20/12/2001', 1040000, N'Midfielder', 'Right'),
(1016, 34, 'Donny van de Beek', null,N'Netherlands', 1.84, 76, '18/04/1997', 6240000, N'Midfielder', 'Right'),
(1016, 37, 'Kobbie Mainoo', null,'England', 1.75, null, '19/04/2005', 0, N'Midfielder', 'Right'),
(1016, 39, 'Scott McTominay', null,'Scotland', 1.93, 88, '08/12/1996', 3120000, N'Midfielder', 'Right'),	
(1016, 44, 'Daniel Gore', null,'England', null, null, '26/09/2004', 0, N'Midfielder', 'Right'),	
(1016, 46, 'Hannibal', null,'Tunisia', 1.77, 74, '21/01/2003', 180000, N'Midfielder', 'Right'),	

-------------------Forwards-------------------
(1016, 9, 'Anthony Martial', null,N'France', 1.81, 76, '05/12/1995', 13000000, N'Forward', 'Right'),
(1016, 10, 'Marcus Rashford', 'rashford.png','England', 1.80, 70, '31/10/1997', 10400000, N'Forward', 'Right'),
(1016, 11, 'Rasmus Hojlund', null,'Denmark', 1.91, 79, '04/02/2003', 4420000, N'Forward', 'Left'),
(1016, 17, 'Alejandro Garnacho', 'garnacho.png','Argentina', 1.80, 80, '01/07/2004', 2600000, N'Forward', 'Right'),
(1016, 21, 'Antony', 'antony.png','Brazil', 1.74, 63, '24/02/2000', 10400000, N'Forward', 'Left'),
(1016, 25, 'Jadon Sancho', null,'England', 1.80, 76, '25/03/2000', 18200000, N'Forward', 'Right'),
(1016, 47, 'Shola Shoretire', null,'England', 1.70, 70, '02/02/2004', 260000, N'Forward', 'Right')


--15. NEWCASTLE UNITED----------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1017, 1, 'Martin Dúbravka', null,'Slovakia', 1.90, 83, '15/01/1989', 2080000, N'Goalkeeper', 'Right'),
(1017, 18, 'Loris Karius', null,N'Germany', 1.89, 90, '22/06/1993', 520000, N'Goalkeeper', 'Right'),
(1017, 22, 'Nick Pope', 'nickpope.png','England', 1.91, 76, '19/04/1992', 3120000, N'Goalkeeper', 'Right'),
(1017, 29, 'Mark Gillespie', null,'England', 1.92, 83, '27/03/1992', 520000, N'Goalkeeper', null),

-------------------Defenders-------------------
(1017, 2, 'Kieran Trippier', 'trippier.png','England', 1.78, 71, '19/09/1990', 6240000, N'Defender', 'Right'),
(1017, 3, 'Paul Dummett', null,'Wales', 1.83, 82, '26/09/1991', 1820000, N'Defender', 'Left'),
(1017, 4, 'Sven Botman', 'svenbotman.png',N'Netherlands', 1.93, 81, '12/01/2000', 4680000, N'Defender', 'Left'),
(1017, 5, N'Fabian Schär', null,N'Switzerland', 1.86, 84, '20/12/1991', 2080000, N'Defender', 'Right'),
(1017, 6, 'Jamaal Lascelles', null,'England', 1.88, 89, '11/11/1993', 2080000, N'Defender', 'Right'),
(1017, 13, 'Matt Targett', null,'England', 1.83, 70, '18/09/1995', 5200000, N'Defender', 'Left'),
(1017, 17, 'Emil Krafth', null,N'Sweden', 1.84, 83, '02/08/1994', 2860000, N'Defender', 'Right'),
(1017, 19, 'Javier Manquillo', null,N'Spain', 1.78, 76, '05/05/1994', 1820000, N'Defender', 'Right'),
(1017, 20, N'Lewis Hall', 'lewishall.png',N'England', 1.79, 73, '08/09/2004', 364000, N'Defender', null),
(1017, 21, 'Tino Livramento', null,N'England', 1.82, null, '12/11/2002', 0, N'Defender', 'Right'),
(1017, 33, 'Dan Burn', null,'England', 1.98, 87, '09/05/1992', 1820000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1017, 7, 'Joelinton', 'joelinton.png','Brazil', 1.86, 81, '14/08/1996', 4420000, N'Midfielder', 'Right'),
(1017, 8, 'Sandro Tonali', null,'Italy', 1.81, 79, '08/05/2000', 10920000, N'Midfielder', 'Right'),
(1017, 11, 'Matt Ritchie', null,'Scotland', 1.72, 76, '10/09/1989', 2340000, N'Midfielder', 'Left'),
(1017, 16, 'Jeff Hendrick', null,'Republic of Ireland', 1.85, 79, '31/01/1992', 1820000, N'Midfielder', 'Right'),
(1017, 23, 'Jacob Murphy', null,'England', 1.79, 74, '24/02/1995', 1820000, N'Midfielder', 'Both'),
(1017, 24, N'Miguel Almirón', 'almiron.png','Paraguay', 1.74, 63, '10/02/1994', 3120000, N'Midfielder', 'Left'),
(1017, 28, 'Joe Willock', null,'England', 1.79, 71, '20/08/1999', 4160000, N'Midfielder', 'Right'),
(1017, 32, 'Elliot Anderson', null,'Scotland', 1.79, null, '06/11/2002', 1560000, N'Midfielder', 'Right'),
(1017, 36, 'Sean Longstaff', null,'England', 1.80, 65, '30/10/1997', 2600000, N'Midfielder', 'Right'),
(1017, 39, 'Bruno Guimarães', null,'Brazil', 1.82, 74, '16/11/1997', 6240000, N'Midfielder', 'Right'),
(1017, 67, 'Lewis Miley', 'lewismiley.png','Brazil', null, null, '01/05/2006', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1017, 9, 'Callum Wilson', 'callumwilson.png','England', 1.80, 66, '27/02/1992', 2392000, N'Forward', 'Both'),
(1017, 10, 'Anthony Gordon', 'gordon.png','England', 1.83, 72, '24/02/2001', 3120000, N'Forward', 'Right'),
(1017, 14, 'Alexander Isak', 'alexanderisak.png',N'Sweden', 1.92, 77, '21/09/1999', 6240000, N'Forward', 'Right'),
(1017, 15, N'Harvey Barnes', null,N'England', 1.77, 66, '09/12/1997', 4160000, N'Forward', 'Right')


--16. NOTTINGHAM FOREST---------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1018, 1, 'Matt Turner', 'mattturner.png', N'USA', 1.90, 79, '24/06/1994', 660000, N'Goalkeeper', 'Right'),
(1018, 13, 'Wayne Hennessey', null, 'Wales', 1.98, 90, '24/01/1987', 780000, N'Goalkeeper', 'Right'),
(1018, 23, 'Odysseas Vlachodimos', null, 'Greece', 1.88, 78, '26/04/1994', 0, N'Goalkeeper', 'Right'),
(1018, 34, 'Ethan Horvath', null, N'USA', 1.91, 84, '09/06/1995', 890000, N'Goalkeeper', 'Right'),
(1018, 38, 'George Shelvey', null, N'England', 1.88, 83, '22/04/2001', 0, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1018, 2, 'Giulian Biancone', null, N'France', 1.87, null, '31/03/2000', 1040000, N'Defender', 'Right'),
(1018, 3, N'Nuno Tavares', null, N'Portugal', 1.83, 75, '19/12/1997', 0, N'Defender', 'Left'),
(1018, 4, 'Joe Worrall', null, 'England', 1.93, 64, '10/01/1997', 780000, N'Defender', 'Right'),
(1018, 7, 'Neco Williams', null, 'Wales', 1.83, 72, '13/04/2001', 2600000, N'Defender', 'Right'),
(1018, 15, 'Harry Toffolo', 'harrytoffolo.png', 'England', 1.83, 71, '19/08/1995', 780000, N'Defender', 'Left'),
(1018, 18, N'Felipe', 'felipe.png', 'Brzail', 1.90, 83, '16/05/1989', 4160000, N'Defender', 'Right'),
(1018, 19, N'Moussa Niakhaté', null, 'Senegal', 1.90, 82, '08/03/1996', 2340000, N'Defender', 'Left'),
(1018, 24, N'Sèrge Aurier', null, N'Côte dIvoire', 1.76, 76, '24/12/1992', 1820000, N'Defender', 'Right'),
(1018, 26, 'Scott Mckenna', null, 'Scotland', 1.89, 74, '12/11/1996', 1040000, N'Defender', 'Left'),
(1018, 29, 'Gonzalo Montiel', null, 'Argentina', 1.75, 68, '01/01/1997', 0, N'Defender', 'Right'),
(1018, 30, 'Willy Boly', null, N'Côte dIvoire', 1.95, 92, '03/02/1991', 2080000 , N'Defender', 'Right'),
(1018, 39, 'Jonathan Panzo', null, 'England', 1.85, 72, '25/10/2000', 0, N'Defender', 'Left'),
(1018, 42, N'Mohamed Dräger', null, 'Tunisia', 1.80, 75, '25/06/1996', 0, N'Defender', 'Right'),
(1018, 43, 'Ola Aina', 'olaaina.png', 'Nigeria', 1.84, 82, '08/10/1996', 2080000, N'Defender', 'Right'),

-------------------Midfielders-------------------
(1018, 5, 'Orel Mangala', null, N'Belgium', 1.78, 80, '18/03/1998', 1560000, N'Midfielder', 'Right'),
(1018, 6, 'Jonjo Shelvey', null, 'England', 1.84, 80, '27/02/1992', 3900000, N'Midfielder', 'Right'),
(1018, 10, 'Morgan Gibbs-White', null, 'England', 1.71, null, '27/01/2000', 4160000, N'Midfielder', 'Right'),
(1018, 8, 'Cheikhou Kouyaté', 'cheikhoukouyaté.png', 'Senegal', 1.89, 83, '21/12/1989', 2340000, N'Midfielder', 'Right'),
(1018, 12, N'Andrey Santos', null, N'Brazil', 1.80, 75, '03/05/2003', 520000, N'Midfielder', null),
(1018, 16, N'Nicolás Domínguez', null, N'Argentina', 1.79, 73, '28/06/1998', 0, N'Midfielder', 'Right'),
(1018, 22, 'Ryan Yates', 'ryanyates.png', 'England', 1.90, 87, '21/11/1997', 1300000, N'Midfielder', null),
(1026, 23, 'Remo Freuler', null, N'Switzerland', 1.81, 80, '15/04/1992', 2080000, N'Midfielder', 'Right'),
(1018, 28, 'Danilo', 'danilo.png', 'Brazil', 1.76, 69, '29/04/2001', 1560000, N'Midfielder', null),
(1018, 32, 'Lewis OBrien', null, 'England', 1.73, 63, '14/08/1998', 780000, N'Midfielder', 'Right'),
(1018, 41, 'Brandon Aguilera', null, 'Costa Rica', 1.79, 60, '28/06/2003', 0, N'Midfielder', 'Left'),
(1018, 44, 'Tyrese Fornah', null, 'England', 1.81, 78, '11/09/1999', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1018, 9, 'Taiwo Awoniyi', 'taiwoawoniyi.png', 'Nigeria', 1.83, 84, '12/08/1997', 2600000, N'Forward', 'Right'),
(1018, 11, 'Chris Wood', 'chriswood.png', 'New Zealand', 1.91, 81, '07/12/1991', 4160000, N'Forward', 'Right'),
(1018, 14, 'Callum Hudson-Odoi', null, 'England', 1.82, 76, '07/11/2000', 0, N'Forward', 'Right'),
(1018, 17, 'Alex Mighten', null, 'England', null, null, '11/04/2002', 180000, N'Forward', null),
(1018, 21, 'Anthony Elanga', null, N'Sweden', 1.78, 70, '27/04/2002', 1300000, N'Forward', 'Right'),
(1018, 25, 'Emmanuel Dennis', null, 'Nigeria', 1.75, 67, '15/11/1997', 2080000, N'Forward', 'Right'),
(1018, 27, 'Divock Origi', 'divockorigi.png', 'Belgium', 1.85, 75, '18/04/1995', 6240000, N'Forward', 'Both'),
(1018, 35, 'Hwang Ui-jo', null, 'South Korea', 1.85, 74, '28/08/1992', 1560000, N'Forward', 'Left')


----17. Sheffield United
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1021, 1, 'Adam Davies', 'adamdavies.png', N'Wales', 1.85, 75, '17/07/1992', 1040000, N'Goalkeeper', 'Right'),
(1021, 18, 'Wes Foderingham', null, N'England', 1.85, 75, '14/01/1991', 390000, N'Goalkeeper', 'Left'),
(1021, 37, 'Jordan Amissah', null, N'Ghana', 1.97, null, '02/08/2001', 820000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1021, 2, 'George Baldock', null, N'Greece', 1.78, 71, '09/03/1993', 210000, N'Defender', 'Right'),
(1021, 3, 'Max Lowe', 'maxlowe.png', N'England', 1.75, 75, '11/05/1997', 230000, N'Defender', 'Left'),
(1021, 5, 'Auston Trusty', null, N'USA', 1.91, 84, '12/08/1998', 210000, N'Defender', 'Left'),
(1021, 6, 'Chris Basham', 'chrisbasham.png', N'England', 1.90, 80, '20/07/1988', 490000, N'Defender', 'Right'),
(1021, 12, 'John Egan', 'johnegan.png', N'Republic of Ireland', 1.85, 75, '20/10/1992', 390000, N'Defender', 'Right'),
(1021, 14, 'Luke Thomas', null, 'England', 1.81, null, '10/06/2001', 520000, N'Defender', 'Left'),
(1021, 15, 'Anel Ahmedhodzic', null, N'Bosnia-Herzegovina', 1.95, 84, '26/03/1999', 1300000, N'Defender', 'Right'),
(1021, 19, 'Jack Robinson', null, N'England', 1.80, 67, '01/09/1993', 1040000, N'Defender', 'Left'),
(1021, 20, 'Jayden Bogle', null, N'England', null, null, '27/07/2000', 860000, N'Defender', null),
(1021, 27, 'Yasser Larouci', null, N'France', 1.76, 68, '01/01/2001', 0, N'Defender','Left'),
(1021, 33, 'Rhys Norrington-Davies', null, N'Wales', 1.81, 68, '22/04/1999', 20800, N'Defender', 'Left'),
(1021, 38, 'Femi Seriki', null, N'England', 1.83, null, '28/04/2002', 0, N'Defender', null),
(1021, null, 'Sai Sachdev', null, N'England', null, null, '23/10/2004', 0, N'Defender', null),
(1021, 40, 'Jili Buyabu', null, N'England', null, null, '09/08/2001', 0, N'Defender', null),

-------------------Midfielders-------------------
(1021, 4, 'John Fleck', null, N'Scotland', 1.70, 72, '24/08/1991', 1040000, N'Midfielder', 'Left'),
(1021, 8, 'Gustavo Hamer', 'gustavohamer.png', N'Netherlands', 1.69, 61, '24/06/1997', 0, N'Midfielder', 'Right'),
(1021, 16, 'Oliver Norwood', null, N'Northern Ireland', 1.80, 75, '12/04/1991', 780000, N'Midfielder', 'Right'),
(1021, 17, 'Ismaila Coulibaly', null, N'Mali', 1.83, 68, '25/12/2000', 312000, N'Midfielder', 'Right'),
(1021, 21, 'Vinicius Souza', null, N'Brazil', 1.87, 80, '17/06/1999', 0, N'Midfielder', 'Right'),
(1021, 22, 'Tom Davies', 'tomdavies.png', N'England', 1.80, 70, '30/06/1998', 0, N'Forward', 'Right'),
(1021, 23, 'Ben Osborn', 'benosborn.png', N'England', 1.76, 75, '05/08/1994', 780000, N'Midfielder', 'Left'),
(1021, 25, 'Anis Ben Slimane', null, N'Tunisia', 1.88, 86, '16/03/2001', 0, N'Midfielder', 'Both'),
(1021, 28, 'James McAtee', null, 'England', null, null, '18/10/2002', 0, N'Midfielder', null),
(1021, 29, 'Iliman Ndiaye', null, N'Senegal', 1.80, 70, '06/03/2000', 200000, N'Midfielder', null),
(1021, 35, 'Andre Brooks', null, N'England', 1.80, null, '20/08/2003', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1021, 7, 'Rhian Brewster', 'rhianbrewster.png', N'England', 1.80, 75, '01/04/2000', 1430000, N'Forward', 'Right'),
(1021, 9, 'Oliver McBurnie', null, N'Scotland', 1.88, 79, '04/06/1996', 1040000, N'Forward', 'Right'),
(1021, 10, N'Cameron Archer', null, N'England', 1.71, 72, '09/12/2001', 0, N'Forward', 'Right'),
(1021, 11, 'Bénie Traoré', null, N'Côte dIvoire', 1.72, 64, '30/11/2002', 0, N'Forward', 'Right'),
(1021, 32, 'William Osula', 'willamosula.png', N'Denmark', 1.80, 81, '04/08/2003', 60000, N'Forward', null),
(1021, 34, 'Louie Marsh', 'louiemarsh.png', N'England', 1.76, 65, '16/10/2003', 0, N'Forward', null),
(1021, 36, 'Daniel Jebbison', null, N'Cananda', 1.90, 69, '11/07/2003', 30000, N'Forward', 'Left'),
(1021, 39, 'Antwoine Hackford', null, N'England', 1.77, null, '20/03/2004', 0, N'Forward', 'Right')


--18. TOTTENHAM-----------------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image], Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1022, 1, 'Hugo Lloris', null,N'France', 1.88, 82, '26/12/1986', 5200000, N'Goalkeeper', 'Left'),
(1022, 13, 'Guglielmo Vicario', 'vicario.png','Italy', 1.94, 83, '07/10/1996', 3900000, N'Goalkeeper', 'Right'),
(1022, 20, 'Fraser Forster', null,'England', 2.01, 93, '17/03/1988', 3900000, N'Goalkeeper', 'Right'),
(1022, 40, 'Brandon Austin', null,'England', 1.88, 82, '08/01/1999', 390000, N'Goalkeeper', null),
(1022, 41, 'Alfie Whiteman', null,'England', 1.89, 84, '02/10/1998', 3900000, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1022, 6, N'Davinson Sánchez', null,N'Colombia', 1.87, 81, '12/06/1996', 3380000, N'Defender', 'Right'),	
(1022, 12, N'Emerson Royal', 'emersonroyal.png',N'Brazil', 1.81, 79, '14/01/1999', 2080000, N'Defender', 'Right'),	
(1022, 15, N'Eric Dier', null,N'England', 1.88, 83, '15/01/1994', 4420000, N'Defender', 'Right'),
(1022, 17, N'Cristian Romero', null,N'Argentina', 1.85, 79, '27/04/1998', 8580000, N'Defender', 'Right'),
(1022, 23, N'Pedro Porro', 'pedroporro.png',N'Spain', 1.76, 71, '13/09/1999', 4420000, N'Defender', 'Right'),
(1022, 24, N'Djed Spence', null,N'England', 1.85, null, '09/08/2000', null, N'Defender', null),
(1022, 25, N'Japhet Tanganga', null,N'England', 1.84, 76, '31/03/1999', 1300000, N'Defender', 'Right'),
(1022, 33, N'Ben Davies', 'bendavies.png',N'Wales', 1.81, 77, '24/04/1993', 4160000, N'Defender', 'Left'),
(1022, 35, N'Ashley Phillips', null,N'England', 1.92, null, '26/06/2005', 780000, N'Defender', 'Right'),
(1022, 37, N'Micky van de Ven', null,N'Netherlands', 1.93, 81, '19/04/2001', 0, N'Defender', 'Left'),
(1022, 38, N'Destiny Udogie', null,N'Italy', 1.86, 67, '28/11/2002', 0, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1022, 4, 'Oliver Skipp', 'oliverskipp.png','England', 1.75, 70, '16/09/2000', 2080000, N'Midfielder', 'Right'),
(1022, 5, N'Pierre-Emile Højbjerg', null,N'Denmark', 1.87, 84, '05/08/1995', 5200000, N'Midfielder', 'Right'),
(1022, 8, N'Yves Bissouma', null,N'Mali', 1.82, 80, '30/08/1996', 2860000, N'Midfielder', 'Right'),
(1022, 10, N'James Maddison', null,N'England', 1.75, 73, '23/11/1996', 0, N'Midfielder', 'Right'),
(1022, 14, N'Ivan Perišić', null,N'Croatia', 1.86, 80, '02/02/1989', 9360000, N'Midfielder', 'Both'),
(1022, 18, N'Giovani Lo Celso', 'locelso.png',N'Argentina', 1.77, 68, '09/04/1996', 3640000, N'Midfielder', 'Left'),
(1022, 19, N'Ryan Sessegnon', null,N'England', 1.78, 70, '18/05/2000', 2860000, N'Midfielder', 'Left'),
(1022, 21, N'Dejan Kulusevski', 'kulusevski.png',N'Sweden', 1.86, 80, '25/04/2000', 5720000, N'Midfielder', 'Left'),
(1022, 28, N'Tanguy Ndombélé', null,N'France', 1.87, 72, '25/06/1997', 3900000, N'Midfielder', 'Right'),
(1022, 29, N'Pape Sarr', null,N'Senegal', 1.85, 70, '14/09/2002', 572000, N'Midfielder', null),
(1022, 30, N'Rodrigo Bentancur', null,N'Uruguay', 1.87, 72, '25/06/1997', 3900000, N'Midfielder', 'Right'),

-------------------Forwards-------------------
(1022, 7, N'Son Heung-Min', 'heungminson.png',N'South Korea', 1.84, 77, '08/07/1992', 9880000, N'Forward', 'Both'),	
(1022, 9, N'Richarlison', 'richarlison.png',N'Brazil', 1.84, 83, '10/05/1997', 4680000, N'Forward', 'Right'),	
(1022, 11, N'Bryan Gil', 'bryangil.png',N'Spain', 1.75, 60, '11/02/2001', 2080000, N'Forward', 'Left'),
(1022, 22, N'Brennan Johnson', null,N'Wales', 1.86, 73, '23/05/2001', 0, N'Forward', 'Right'),
(1022, 27, N'Manor Solomon', null,N'England', 1.70, 66, '24/07/1999', 0, N'Forward', 'Both'),
(1022, 36, N'Alejo Véliz', null,N'Argentina', 1.86, 77, '19/09/2003', 0, N'Forward', 'Right')


--19. WEST HAM UNITED-----------------------------------------------------------------
-------------------Goalkeepers-------------------
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1023, 1, N'Ł. Fabiański', null, 'Poland', 1.90, 83, '18/04/1985', 3380000, N'Goalkeeper', 'Right'),
(1023, 23, N'Alphonse Aréola', 'alphonseareola.png', N'France', 1.95, 94, '27/03/1993', 6240000, N'Goalkeeper', 'Right'),
(1023, 25, N'Nathan Trott', null, N'England', 1.88, null, '21/11/1998', 0, N'Goalkeeper', 'Right'),
(1023, 49, N'Joseph Anang', null, N'England', 1.90, 72, '08/06/2000', 57200, N'Goalkeeper', 'Right'),

-------------------Defenders-------------------
(1023, 2, N'Ben Johnson', 'benjohnson.png', N'England', 1.75, 67, '24/01/2000', 1040000, N'Defender', 'Right'),
(1023, 3, N'Aaron Cresswell', null, N'England', 1.70, 66, '15/12/1989', 2600000, N'Defender', 'Left'),
(1023, 4, N'Kurt Zouma', 'kurtzouma.png', N'France', 1.90, 96, '27/10/1994', 6500000, N'Defender', 'Right'),
(1023, 5, N'Vladimír Coufal', null, N'Czechia', 1.79, 76, '22/08/1992', 1820000, N'Defender', 'Right'),
(1023, 15, N'Konstantinos Mavropanos', null, N'Greece', 1.94, 94, '11/12/1997', 2600000, N'Defender', 'Right'),
(1023, 21, N'Angelo Ogbonna', null, N'Italy', 1.91, 86, '23/05/1988', 3640000, N'Defender', 'Left'),
(1023, 24, N'Thilo Kehrer', null, N'Germany', 1.86, 76, '21/09/1996', 4160000, N'Defender', 'Right'),
(1023, 27, N'Nayef Aguerd', 'nayefaguerd.png', N'Morocco', 1.90, 76, '30/03/1996', 2600000, N'Defender', 'Left'),
(1023, 33, N'Emerson Palmieri', null, N'Brazil', 1.76, 63, '03/08/1994', 4940000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1023, 7, N'James Ward-Prowse', null, N'England', 1.73, 66, '01/11/1994', 0, N'Midfielder', 'Right'),
(1023, 8, N'Pablo Fornals', null, N'Spain', 1.78, 67, '22/02/1996', 3380000, N'Midfielder', 'Right'),
(1023, 10, N'Lucas Paquetá', null, N'Brazil', 1.80, 72, '27/08/1997', 7800000, N'Midfielder', 'Left'),
(1023, 12, N'Flynn Downes', null, N'England', 1.73, 70, '20/01/1999', 1300000, N'Midfielder', 'Right'),
(1023, 14, N'Mohammed Kudus', 'mohammedkudus.png', N'Ghana', 1.77, 70, '02/08/2000', 0, 'Midfielder','Left'),
(1023, 17, N'Maxwel Cornet', null, N'Côte dIvoire', 1.79, 69, '27/09/1996', 3380000, N'Midfielder', 'Right'),
(1023, 19, N'Edson Álvarez', 'edsonalvarez.png', N'Mexico', 1.87, 73, '24/10/1997', 0, N'Midfielder', 'Right'),
(1023, 28, N'Tomás Souček', 'tomassoucek.png', N'Czechia', 1.92, 86, '27/02/1995', 3380000, N'Midfielder', 'Right'),
(1023, 32, N'Conor Coventry', null, N'England', null, null, '25/10/2004', 0, N'Midfielder', null),

-------------------Forwards-------------------
(1023, 9, N'Michail Antonio', null, N'Jamaica', 1.80, 82, '28/03/1990', 4420000, N'Forward', 'Right'),
(1023, 18, N'Danny Ings', 'dannyings.png', N'England', 1.78, 73, '23/07/1992', 6500000, N'Forward', 'Right'),
(1023, 20, N'Jarrod Bowen', 'jarrodbowen.png', N'England', 1.75, 70, '20/12/1996', 3120000, N'Forward', 'Left'),
(1023, 22, N'Saïd Benrahma', null, N'Algeria', 1.72, 67, '10/08/1995', 2860000, N'Forward', 'Left'),
(1023, 45, N'Divin Mubama', 'divinmubama.png', N'Algeria', 1.72, 67, '10/08/1995', 2860000, N'Forward', 'Left')


--20. WOLVERHAMPTON WANDERERS---------------------------------------------------------
-------------------Goalkeepers-------------------
----José Sá
GO
INSERT INTO Players(ClubID, Number, PlayerName, [Image],Country, Height, [Weight], DOB, Salary, Position, Foot)
VALUES(1025, 1, N'José Sá', null, 'Portugal', 1.92, 84, '17/01/1993', 1300000, N'Goalkeeper', 'Right'),
(1025, 25, 'Daniel Bentley', null, 'England', 1.88, 72, '13/07/1993', 520000, N'Goalkeeper', 'Right'),
(1025, 40, 'Tom King', 'king.png', 'Wales', 1.85, 80, '09/03/1995', 0, N'Goalkeeper', null),

-------------------Defenders-------------------
(1025, 2, 'Matt Doherty', null, 'Northern Ireland', 1.75, 63, '24/03/1997', 0, N'Defender', null),
(1025, 3, N'Rayan Aït-Nouri', null, 'Algeria', 1.79, 70, '06/06/2001', 520000, N'Defender', 'Left'),
(1025, 4, N'Santiago Bueno', 'bueno.png', 'Uruguay', 1.90, 76, '09/11/1998', 0, N'Defender', 'Right'),
(1025, 15, 'Craig Dawson', 'dawson.png', 'England', 1.88, 82, '06/05/1990', 2340000, N'Defender', 'Right'),
(1025, 17, N'Hugo Bueno', null, N'Spain', 1.80, 73, '18/09/2002', 260000, N'Defender', 'Left'),
(1025, 19, 'Jonny Otto', null, N'Spain', 1.75, 70, '03/03/1990', 2340000, N'Defender', 'Both'),
(1025, 22, N'Nélson Semedo', null, N'Portugal', 1.77, 67, '16/11/1993', 4160000, N'Defender', 'Right'),
(1025, 23, N'Maximilian Kilman', null, 'England', 1.94, 89, '23/05/1997', 780000, N'Defender', 'Left'),
(1025, 24, N'Toti Gomes', 'totigomes.png', N'Portugal', 1.87, 83, '23/05/1997', 520000, N'Defender', 'Left'),

-------------------Midfielders-------------------
(1025, 5, N'Mario Lemina', 'mariolemina.png', 'Gabon', 1.84, 85, '01/09/1993', 2340000, N'Midfielder', 'Right'),
(1025, 6, N'Boubacar Traoré', null, 'Mali', 1.83, 67, '20/08/2001', 2860000, N'Midfielder', null),
(1025, 8, N'João Gomes', 'gomes.png', N'Portugal', 1.74, 74, '08/09/1986', 1560000, N'Midfielder', null),
(1025, 20, N'Tommy Doyle', 'tommydoyle.png', N'England', 1.72, null, '17/10/2001', 0, N'Midfielder', 'Right'),
(1025, 27, N'Jean-Ricner Bellegarde', null, N'France', 1.72, 70, '27/06/1998', 0, N'Midfielder', 'Right'),
(1025, 32, N'Joseph Hodge', null, N'Republic of Ireland', 1.72, null, '12/02/2001', 260000, N'Midfielder', null),

-------------------Forwards-------------------
(1025, 7, N'Pedro Neto', 'pedroneto.png', N'Portugal', 1.72, 62, '09/03/2000', 2600000, N'Forward',  'Left'),
(1025, 9, N'Fábio Silva', null, N'Portugal', 1.85, 75, '19/07/2002', 4160000, N'Forward',  'Right'),
(1025, 11, N'Hwang Hee-Chan', null, N'South Korea', 1.77, 77, '26/01/1996', 1560000, N'Forward',  'Right'),
(1025, 12, N'Matheus Cunha', null, N'Brazil', 1.84, 76, '27/05/1999', 3120000, N'Forward',  'Right'),
(1025, 18, N'Sasa Kalajdzic', null, N'Austria', 2.00, 93, '07/07/1997', 1820000, N'Forward',  null),
(1025, 21, N'Pablo Sarabia', 'pablosarabia.png', N'Spain', 1.74, 70, '11/05/1992', 4680000, N'Forward',  'Left'),
(1025, 30, N'Enso Gonzalez', 'ensogonzalez.png', N'Paraguay', 1.69, 69, '20/01/2005', 0, N'Forward',  'Left'),
(1025, 63, N'Nathan Fraser', null, N'Republic of Ireland', null, null, '22/02/2005', 0, N'Forward',  null)

--select * from clubs where ClubID = 1017
--delete Players from Players
--select * from Stadiums
---------------------------------------------------------------------------------------------------------------------------------