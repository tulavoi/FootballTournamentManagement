﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY

--Chèn bảng Referees----------------------------------------------------------------------------------------------------------------
GO
INSERT INTO Referees(RefereeName, Country, DOB)
VALUES 
('Anthony Taylor', 'England', '1978-10-20'),
('Michael Oliver', 'England', '1985-02-20'),
('Simon Hooper', 'England', '1982-07-15'),
('Paul Tierney', 'England', '1980-06-22'),
('John Brooks', 'England', NULL),
('Robert Jones', 'England', '1987-04-04'),
('Andy Madley', 'England', '1983-09-05'),
('Tim Robinson', 'England', NULL),
('Jarred Gillett', 'Australia', '1986-11-01'),
('Chris Kavanagh', 'England', '1985-09-04'),
('Samuel Barrott', 'England', NULL),
('Craig Pawson', 'England', '1979-03-02'),
('Stuart Attwell', 'England', '1982-10-06'),
('David Coote', 'England', '1982-07-11'),
('Michael Salisbury', 'England', NULL),
('Peter Bankes', 'England', '1982-05-18'),
('Thomas Bramall', 'England', NULL),
('Darren England', 'England', '1985-12-23'),
('Tony Harrington', 'England', NULL),
('Darren Bond', 'England', NULL);

--select * from Referees where RefereeName = 'Simon Hooper'
-------------------------------------------------------------------------------------------------------------------------------