﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY


GO
INSERT INTO Seasons(SeasonName, StartDate, EndDate)
VALUES('21/22', '14/8/2021', '22/5/2022'),
('22/23', '06/08/2022', '28/05/2023'),
('23/24', '12/08/2023', '19/05/2024')


--SELECT * FROM Seasons

--DELETE FROM Seasons where SeasonID = 1006
-------------------------------------------------------------------------------------------------------------------------------