﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY

--Chèn bảng Matches------------------------------------------------------------------------------------------------------------
----1. Matchweek 1
GO
INSERT INTO Matches(MatchID, SeasonID, RoundID, HomeID, AwayID, MatchName)
VALUES('MW1_1003_01', 1003, 'MW1_1003', 1006, 1015, 'Burnley - Man City'),
('MW1_1003_02', 1003, 'MW1_1003', 1001, 1018, 'Arsenal - Nottingham Forest'),
('MW1_1003_03', 1003, 'MW1_1003', 1005, 1013, 'Brighton - Luton Town FC'),
('MW1_1003_04', 1003, 'MW1_1003', 1003, 1023, 'Bournemouth - West Ham'),
('MW1_1003_05', 1003, 'MW1_1003', 1009, 1010, 'Everton - Fulham'),
('MW1_1003_06', 1003, 'MW1_1003', 1021, 1008, 'Sheffield United - Crystal Palace'),
('MW1_1003_07', 1003, 'MW1_1003', 1017, 1002, 'Newcastle - Aston Villa'),
('MW1_1003_08', 1003, 'MW1_1003', 1004, 1022, 'Brentford - Tottenham'),
('MW1_1003_09', 1003, 'MW1_1003', 1007, 1012, 'Chelsea - Liverpool'),
('MW1_1003_10', 1003, 'MW1_1003', 1016, 1025, 'Wolves - Man United');


--('MW1_1003_01', 'MW1', 'Burnley - Man City', '12/08/2023 2:00:00'),
--('MW1_1003_02', 'MW1', 'Arsenal - Nottingham Forest', '12/08/2023 18:30:00'),
--('MW1_1003_04', 'MW1', 'Bournemouth - West Ham', '12/08/2023 21:00:00'),
--('MW1_1003_03', 'MW1', 'Brighton - Luton', '12/08/2023 21:00:00'),
--('MW1_1003_05', 'MW1', 'Everton - Fulham', '12/08/2023 21:00:00'),
--('MW1_1003_06', 'MW1', 'Sheffield United - Crystal Palace', '12/08/2023 21:00:00'),
--('MW1_1003_07', 'MW1', 'Newcastle - Aston Villa', '12/08/2023 23:30:00'),
--('MW1_BRE-TOT', 'MW1', 'Brentford - Tottenham', '13/08/2023 20:00:00'),
--('MW1_CHE-LIV', 'MW1', 'Chelsea - Liverpool', '13/08/2023 22:30:00'),
--('MW1_MUN-WOL', 'MW1', 'Wolves - Man United', '15/08/2023 02:00:00')	

--select * from Matches 
--select * from Matches where RoundID = 'MW1_1001'
--delete from Matches
-------------------------------------------------------------------------------------------------------------------------------