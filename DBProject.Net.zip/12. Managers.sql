﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY

--Chèn bảng Managers----------------------------------------------------------------------------------------------------------------

GO
INSERT INTO Managers(ClubID, ManagerName, [Image], Country, DOB)
VALUES
('1001', 'Mikel Arteta', 'arteta.png', N'Spain', '1982-03-26'),
('1002', 'Unai Emery Etxegoien', 'emery.png', 'Spain', '1971-11-03'),
('1003', 'Iraola', null, 'Spain', '1982-06-22'),
('1004', 'Thomas Frank', 'frank.png', N'Denmark', '1973-10-09'),
('1005', 'Roberto De Zerbi', 'zerbi.png', 'Italia', '1979-06-06'),
('1006', 'Vincent Kompany', null, 'Belgium', '1986-04-10'),
('1007', 'Mauricio Pochettino', 'pochettino.png', 'Argentina', '1972-03-02'),
('1008', 'Oliver Glasner', 'glasner.png', 'Austria', '1974-08-28'),
('1009', 'Sean Dyche', 'dyche.png', 'England', '1971-06-28'),
('1010', 'Marco Silva', 'silva.png', N'Portugal', '1977-07-12'),
('1012', N'Jürgen Klopp', 'klopp.png', N'Germany', '1967-06-16'),
('1013', 'Rob Edwards', null, N'England', '1962-11-25'),
('1015', 'Pep Guardiola', 'guardiola.png', N'Spain', '1971-01-18'),
('1016', 'Erik ten Hag', 'tenhag.png', N'Netherlands', '1970-02-02'),
('1017', 'Eddie Howe', 'howe.png', N'England', '1977-11-29'),
('1018', 'Nuno Espírito Santo', 'santo.png', 'Portugal', '1974-01-25'),
('1021', N'Chris Wilder', 'wilder.png', N'England', '1967-09-23'),
('1022', 'Ange Postecoglou', 'postecoglou.png', 'Greece', '1965-08-27'),
('1023', 'David Moyes', 'moyes.png', N'Scotland', '1963-04-25'),
('1025', 'Gary ONeil', 'oneil.png', N'England', '1983-05-18');

--delete from Managers
--select * from Managers
--insert into Managers(ClubID, ManagerName, [Image], Country, DOB) values('1023', 'aaaaa', null, N'vietnam', '22/12/2001')
-------------------------------------------------------------------------------------------------------------------------------