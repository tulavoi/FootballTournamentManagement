﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY


GO
INSERT INTO Accounts(Email, [Password], Permission)
VALUES('toilavu', 'toilavu', 1),
('thanhcong', 'thanhcong', 1)


--SELECT * FROM Seasons

--DELETE FROM Seasons
-------------------------------------------------------------------------------------------------------------------------------