﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY


--Chèn bảng DoiBong------------------------------------------------------------------------------------------------------------
GO
INSERT INTO Clubs (ClubName, Logo)
VALUES
('Arsenal', 'ars.png'),
('Aston Villa', 'avl.png'),
('Bournemouth', 'bou.png'),
('Brentford', 'bre.png'),
('Brighton', 'bha.png'),
('Burnley FC', 'bur.png'),
('Chelsea', 'che.png'),
('Crystal Palace', 'cry.png'),
('Everton', 'eve.png'),
('Fulham FC', 'ful.png'),
('Leicester City', 'lei.png'),
('Liverpool', 'liv.png'),
('Luton Town FC', 'lut.png'),
('Leeds United', 'lee.png'),
('Manchester City', 'mci.png'),
('Manchester United', 'mun.png'),
('Newcastle United', 'new.png'),
('Nottingham Forest', 'nfo.png'),
('Norwich City', 'nor.png'),
('Southampton', 'sou.png'),
('Sheffield United FC', 'shu.png'),
('Tottenham Hotspur', 'tot.png'),
('West Ham United', 'whu.png'),
('Watford', 'wat.png'),
('Wolverhampton', 'wol.png');


GO
INSERT INTO Clubs(ClubName)
VALUES('none')

--SELECT * FROM Clubs
--SELECT * FROM Stadiums

--DELETE FROM Clubs
-------------------------------------------------------------------------------------------------------------------------------