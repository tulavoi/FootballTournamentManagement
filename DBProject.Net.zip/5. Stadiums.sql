﻿GO
USE [DBProject.Net]
--Cập nhật ngày tháng năm
SET DATEFORMAT DMY

--Chèn bảng StadiumID---------------------------------------------------------------------------------------------------------
GO 
INSERT INTO Stadiums(StadiumID, ClubID, StadiumName, [Image], Size, Capacity, [Location], BuiltTime)
VALUES
('Stadium_1001', '1001', 'Emirates', 'emirates.jpg', '105m x 68m', 60704, 'Emirates Stadium, Hornsey Rd, London N7 7AJ, England', '2006'),
('Stadium_1002', '1002', 'Villa Park', 'villapark.jpg', '101m x 68m', 42000, 'Villa Park, Trinity Rd, Birmingham B6 6HE, England', '1897'),
('Stadium_1003', '1003', 'Vitality', 'vitality.jpg', '105m x 68m', 11329, 'Dean Court, Kings Park, Bournemouth BH7 7AF, England', '1899'),
('Stadium_1004', '1004', 'Brentford Community Stadium', 'brentfordcommunitystadium.jpg', '101m x 68m', 17250, 'Lionel Rd S, Brentford, London TW8 0JA, England', '2018'),
('Stadium_1005', '1005', 'Falmer', 'falmer.jpg', '101m x 68m', 30666, 'American Express Community Stadium, Village Way, Brighton BN1 9BL, England', '2011'),
('Stadium_1006', '1006', 'Turf Moor', 'turfmoor.jpg', '105m x 68m', 21944, 'Harry Potts Way, Burnley, Lancashire, BB10 4BX, England', '1883'),
('Stadium_1007', '1007', 'Stamford Bridge', 'stamfordbridge.jpg', '103,3m x 67,7m', 40853, 'Fulham Rd, Fulham, London SW6 1HS, England', '1877'),
('Stadium_1008', '1008', 'Selhurst Park', 'selhurstpark.jpg', '105m x 68m', 26000, 'Selhurst Park Stadium, London SE25 6PU, England', '1924'),
('Stadium_1009', '1009', 'Goodison Park', 'goodisonpark.jpg', '100m x 68m', 40157, 'Goodison Rd, Liverpool L4 4EL, England', '1892'),
('Stadium_1010', '1010', 'Craven Cottage', 'cravencottage.jpg', '100m x 65m', 19000, 'Stevenage Rd, Fulham, London SW6 6HH, England', '1896'),
('Stadium_1012', '1012', 'Anfield', 'anfield.jpg', '101m x 68m', 56394, 'Anfield Road, Liverpool L4 0TH, England', '1884'),
('Stadium_1013', '1013', 'Kenilworth Road', 'kenilworthroad.jpg', '101m x 68m', 10356, 'Kenilworth Road, Luton, Bedfordshire, LU1 1DH, England', '1905'),
('Stadium_1014', '1014', 'Elland Road', 'ellandroad.jpg', '105m x 68m', 32273, 'Elland Rd, Leeds LS11 0ES, England', '1987'),
('Stadium_1015', '1015', 'Etihad Stadium', 'etihadstadium.jpg', '105m x 68m', 55017, 'Etihad Stadium, Ashton New Rd, Manchester M11 3FF, England', '2002'),
('Stadium_1016', '1016', 'Old Trafford', 'oldtrafford.jpg', '105m x 68m', 74140, 'Sir Matt Busby Way, Stretford, Manchester M16 0RA, England', '1910'),
('Stadium_1017', '1017', 'St.JamesPark', 'stjamespark.jpg', '101m x 68m', 52305, 'Barrack Rd, Newcastle upon Tyne NE1 4ST, England', '1892'),
('Stadium_1018', '1018', 'The City Ground', 'thecityground.jpg', '105m x 68m', 30445, 'The City Ground là Trentside, West Bridgford, Nottinghamshire, NG2 5FJ, England', '1898'),
('Stadium_1021', '1021', 'Bramall Lane', 'bramalllane.jpg', '101m x 68m', 32.702, 'Bramall Lane, Sheffield, South Yorkshire, S2 4SU, England', '1855'),
('Stadium_1022', '1022', 'Tottenham Hotspur Stadium', 'tottenhamhotspurstadium.jpg', '105m x 68m', 62303, '782 High Rd, Tottenham, London N17 0BX, England', '2019'),
('Stadium_1023', '1023', 'London Stadium', 'londonstadium.jpg', '105m x 68m', 60000, 'Queen Elizabeth Olympic Park, London E20 2ST, England', '2008'),
('Stadium_1025', '1025', 'Molineux', 'molineux.jpg', '105m x 68m', 32050, 'Waterloo Rd, Wolverhampton WV1 4QR, England', '1889');


--GO 
--INSERT INTO Stadiums(StadiumID, ClubID, StadiumName, Size, Capacity, [Location], BuiltTime)
--VALUES('None', 'None', 'None', null, null, null, null)
--SELECT * FROM Clubs
--SELECT * FROM Stadiums

-------------------------------------------------------------------------------------------------------------------------------